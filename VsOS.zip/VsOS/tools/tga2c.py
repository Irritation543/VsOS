"""Convert TGA image files to C arrays for embedding in VsOS kernel."""

import sys
import os

def tga_to_c(tga_path, var_name="tga_image"):
    with open(tga_path, "rb") as f:
        data = f.read()

    if len(data) < 18:
        print(f"Error: {tga_path} is too small for a valid TGA", file=sys.stderr)
        return None

    w = data[12] | (data[13] << 8)
    h = data[14] | (data[15] << 8)
    bpp = data[16]
    img_type = data[2]

    print(f"  {tga_path}: {w}x{h} {bpp}bpp type-{img_type} ({len(data)} bytes)")

    lines = [f"static const unsigned char {var_name}_data[] = {{"]
    line = "  "
    for i, byte in enumerate(data):
        line += f"0x{byte:02X},"
        if len(line) > 70:
            lines.append(line)
            line = "  "
    if line.strip():
        lines.append(line)
    lines.append("};")
    lines.append(f"#define {var_name}_W {w}")
    lines.append(f"#define {var_name}_H {h}")
    return "\n".join(lines)

def main():
    if len(sys.argv) < 2:
        print("Usage: python tga2c.py <file.tga> [file2.tga ...]")
        print("Output: C source with embedded TGA data arrays")
        sys.exit(1)

    output = "#ifndef TGA_IMAGES_H\n"
    output += "#define TGA_IMAGES_H\n\n"
    output += "#include <stdint.h>\n\n"

    for path in sys.argv[1:]:
        if not os.path.exists(path):
            print(f"Warning: {path} not found, skipping", file=sys.stderr)
            continue
        base = os.path.splitext(os.path.basename(path))[0]
        var = base.replace("-", "_").replace(" ", "_")
        c = tga_to_c(path, var)
        if c:
            output += c + "\n\n"

    output += "#endif\n"
    print(output)

if __name__ == "__main__":
    main()
