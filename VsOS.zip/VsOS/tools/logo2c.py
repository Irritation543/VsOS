import struct
import os

SRC = os.path.join(os.path.dirname(__file__), '..', 'start_logo.bmp')
DST = os.path.join(os.path.dirname(__file__), '..', 'kernel', 'start_logo.h')

with open(SRC, 'rb') as f:
    data = f.read()

w = struct.unpack_from('<I', data, 18)[0]
h = struct.unpack_from('<I', data, 22)[0]
bpp = struct.unpack_from('<H', data, 28)[0]
pix_off = struct.unpack_from('<I', data, 10)[0]

pix = bpp // 8
pixels = []
for row in range(h):
    y = h - 1 - row
    row_start = pix_off + y * ((w * pix + 3) & ~3)
    for col in range(w):
        off = row_start + col * pix
        b = data[off]
        g = data[off + 1]
        r = data[off + 2]
        a = data[off + 3] if pix == 4 else 255
        pixels.append((r, g, b, a))

with open(DST, 'w') as f:
    f.write(f'// Generated from start_logo.bmp ({w}x{h})\n')
    f.write(f'#ifndef START_LOGO_H\n#define START_LOGO_H\n\n')
    f.write(f'#define LOGO_W {w}\n')
    f.write(f'#define LOGO_H {h}\n\n')
    f.write(f'static const unsigned int logo_data[{h}][{w}] = {{\n')
    for y in range(h):
        f.write('    {')
        for x in range(w):
            idx = y * w + x
            r, g, bb, a = pixels[idx]
            color = (a << 24) | (r << 16) | (g << 8) | bb
            f.write(f'0x{color:08X}')
            if x < w - 1:
                f.write(', ')
        f.write('}')
        if y < h - 1:
            f.write(',')
        f.write('\n')
    f.write('};\n\n')
    f.write('#endif\n')

print(f'Generated {DST} ({w}x{h})')
