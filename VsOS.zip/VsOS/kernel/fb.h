#ifndef FB_H
#define FB_H

#include <stdint.h>

int  fb_init(void);
void fb_putpixel(int x, int y, uint32_t c);
void fb_fillrect(int x, int y, int w, int h, uint32_t c);
void fb_drawchar(int x, int y, char c, uint32_t fg, uint32_t bg);
void fb_drawstr(int x, int y, const char *s, uint32_t fg, uint32_t bg);
void fb_rect3d(int x, int y, int w, int h, uint32_t light, uint32_t dark);
void fb_setclip(int x, int y, int w, int h);
void fb_resetclip(void);

void fb_use_backbuffer(void);
void fb_use_frontbuffer(void);
void fb_present(void);

uint32_t *fb_getptr(void);
extern int fb_w, fb_h;

#endif
