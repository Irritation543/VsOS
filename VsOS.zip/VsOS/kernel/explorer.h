#ifndef EXPLORER_H
#define EXPLORER_H

void explorer_open(void);

#endif