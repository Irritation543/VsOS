#include "sound.h"
#include "../arch/i386/io.h"
#include "string.h"

/* ===== PC Speaker ===== */
void beep(int freq, int duration_ms)
{
    if (freq <= 0) return;
    uint32_t div = 1193180 / freq;
    outb(0x43, 0xB6);
    outb(0x42, div & 0xFF);
    outb(0x42, (div >> 8) & 0xFF);
    uint8_t tmp = inb(0x61);
    outb(0x61, tmp | 3);
    for (volatile int i = 0; i < duration_ms * 10000; i++)
        asm volatile("pause");
    outb(0x61, tmp & ~3);
}

/* ===== AC97 on QEMU (Intel ICH) ===== */
#define AC97_VENDOR 0x8086
#define AC97_DEVICE 0x2415

uint16_t nambar;
uint16_t nabmbar;
static int ac97_initialized = 0;

typedef struct {
    uint32_t buf_addr;
    uint16_t buf_len;
    uint16_t flags;   /* bit 15 = IOC */
} __attribute__((packed)) bd_entry_t;

#define AUDIO_BUF_SIZE 65536
unsigned char audio_buf[AUDIO_BUF_SIZE] __attribute__((aligned(128)));
bd_entry_t bdl[4] __attribute__((aligned(64)));

uint32_t ac97_get_bdl_addr(void) { return (uint32_t)(uintptr_t)bdl; }
uint32_t ac97_get_buf_addr(void) { return (uint32_t)(uintptr_t)audio_buf; }
int      ac97_get_bdl_aligned(void) { return (int)(uintptr_t)bdl & 0x3F; }
int      ac97_get_buf_aligned(void) { return (int)(uintptr_t)audio_buf & 0x7F; }

static uint32_t pci_conf_read(uint8_t bus, uint8_t dev, uint8_t func, uint8_t reg)
{
    uint32_t addr = 0x80000000 | ((uint32_t)bus << 16) |
                    ((uint32_t)(dev & 31) << 11) |
                    ((uint32_t)(func & 7) << 8) | (reg & 0xFC);
    outl(0xCF8, addr);
    return inl(0xCFC);
}

static int find_ac97(void)
{
    for (int dev = 0; dev < 32; dev++) {
        for (int func = 0; func < 8; func++) {
            uint32_t vid = pci_conf_read(0, dev, func, 0);
            uint16_t vendor = vid & 0xFFFF;
            uint16_t device = (vid >> 16) & 0xFFFF;
            if (vendor == 0xFFFF) break;

            uint32_t cc = pci_conf_read(0, dev, func, 0x08);
            uint8_t class_code = (cc >> 24) & 0xFF;
            uint8_t subclass = (cc >> 16) & 0xFF;

            if ((vendor == AC97_VENDOR && device == AC97_DEVICE) ||
                (class_code == 0x04 && subclass == 0x01)) {
                uint32_t bar0 = pci_conf_read(0, dev, func, 0x10);
                uint32_t bar1 = pci_conf_read(0, dev, func, 0x14);
                if (bar0 & 1) nambar  = bar0 & 0xFFFC;
                else          nambar  = (bar0 & 0xFFFFFFF0) & 0xFFFF;
                if (bar1 & 1) nabmbar = bar1 & 0xFFFC;
                else          nabmbar = (bar1 & 0xFFFFFFF0) & 0xFFFF;
                return 1;
            }
        }
    }
    return 0;
}

/* Debug: dump AC97 state to a buffer (for play command) */
void ac97_get_info(char *buf, int max_len)
{
    (void)max_len;
    int pos = 0;

    /* Try to detect if not already found */
    uint16_t tnambar = nambar, tnabmbar = nabmbar;
    if (!tnambar && !tnabmbar) {
        for (int dev = 0; dev < 32; dev++) {
            for (int func = 0; func < 8; func++) {
                uint32_t vid = pci_conf_read(0, dev, func, 0);
                uint16_t vendor = vid & 0xFFFF;
                uint16_t device = (vid >> 16) & 0xFFFF;
                if (vendor == 0xFFFF) break;
                uint32_t cc = pci_conf_read(0, dev, func, 0x08);
                uint8_t class_code = (cc >> 24) & 0xFF;
                uint8_t subclass = (cc >> 16) & 0xFF;
                int match = (vendor == AC97_VENDOR && device == AC97_DEVICE) ||
                            (class_code == 0x04 && subclass == 0x01);
                if (match) {
                    pos += 1;
                    buf[0] = 'F'; buf[1] = 'O'; buf[2] = 'U'; buf[3] = 'N';
                    buf[4] = 'D'; buf[5] = '!'; buf[6] = ' ';
                    pos = 7;
                    uint32_t bar0 = pci_conf_read(0, dev, func, 0x10);
                    uint32_t bar1 = pci_conf_read(0, dev, func, 0x14);
                    tnambar  = bar0 & 1 ? (bar0 & 0xFFFC) : 0;
                    tnabmbar = bar1 & 1 ? (bar1 & 0xFFFC) : 0;
                    dev = 32; break;
                }
            }
        }
    }

    if (!tnambar && !tnabmbar) {
        buf[0] = 'N'; buf[1] = 'F'; buf[2] = 0;
        return;
    }

    static const char hex[] = "0123456789ABCDEF";
    unsigned int v;
    v = tnambar;
    buf[pos++] = 'M'; buf[pos++] = ':'; buf[pos++] = '0'; buf[pos++] = 'x';
    { char t[16]; int ti = 0;
      if (v == 0) t[ti++] = '0';
      else { while (v) { t[ti++] = hex[v & 0xF]; v >>= 4; } }
      for (int j = ti-1; j >= 0; j--) buf[pos++] = t[j]; }
    buf[pos++] = ' ';

    v = tnabmbar;
    buf[pos++] = 'B'; buf[pos++] = ':'; buf[pos++] = '0'; buf[pos++] = 'x';
    { char t[16]; int ti = 0;
      if (v == 0) t[ti++] = '0';
      else { while (v) { t[ti++] = hex[v & 0xF]; v >>= 4; } }
      for (int j = ti-1; j >= 0; j--) buf[pos++] = t[j]; }
    buf[pos] = 0;
}

static void mix_w(uint8_t r, uint16_t v) { outw(nambar + r, v); }
static uint16_t mix_r(uint8_t r) { return inw(nambar + r); }
static void bm_w8(uint8_t r, uint8_t v) { outb(nabmbar + r, v); }
static uint8_t bm_r8(uint8_t r) { return inb(nabmbar + r); }
static void bm_w16(uint8_t r, uint16_t v) { outw(nabmbar + r, v); }
static uint16_t bm_r16(uint8_t r) { return inw(nabmbar + r); }
static void bm_w32(uint8_t r, uint32_t v) { outl(nabmbar + r, v); }

int ac97_init(void)
{
    if (ac97_initialized) return 1;
    if (!find_ac97()) return 0;

    /* Reset mixer */
    mix_w(0x00, 0x0000);
    for (volatile int i = 0; i < 200000; i++) asm("pause");
    if (mix_r(0x00) == 0xFFFF) return 0;

    /* Enable VRA (Variable Rate Audio) so sample rate writes take effect */
    mix_w(0x2A, 0x0100);

    /* Unmute volumes: Master, PCM Out, Headphone, Mono, PC Beep */
    mix_w(0x02, 0x0000);  /* Master volume: max, no mute */
    mix_w(0x18, 0x0000);  /* PCM Out volume: max, no mute */
    mix_w(0x04, 0x0000);  /* Headphone volume: max, no mute */
    mix_w(0x06, 0x0000);  /* Mono volume */
    mix_w(0x0A, 0x0000);  /* PC Beep volume */
    mix_w(0x1A, 0x0000);  /* Mono select */
    mix_w(0x1C, 0x0000);  /* Mic volume */

    /* Set sample rates to 48000 */
    mix_w(0x2C, 48000);  /* PCM Front DAC rate */
    mix_w(0x32, 48000);  /* PCM Front ADC rate */

    /* Check that PCM volume actually changed (sanity) */
    if (mix_r(0x18) == 0x8808) return 0;

    /* Clear bus master status */
    bm_w16(0x16, 0x003F);

    ac97_initialized = 1;
    return 1;
}

/* Fixed-point sine LUT (128 entries -> 0..2pi, Q15) */
#define SIN_LUT_SIZE 128
static const int16_t sin_lut[SIN_LUT_SIZE] = {
    0, 1607, 3211, 4807, 6392, 7961, 9511, 11038,
    12539, 14009, 15446, 16845, 18204, 19519, 20787, 22004,
    23169, 24278, 25329, 26318, 27244, 28105, 28897, 29621,
    30272, 30851, 31356, 31785, 32137, 32412, 32609, 32727,
    32767, 32727, 32609, 32412, 32137, 31785, 31356, 30851,
    30272, 29621, 28897, 28105, 27244, 26318, 25329, 24278,
    23169, 22004, 20787, 19519, 18204, 16845, 15446, 14009,
    12539, 11038, 9511, 7961, 6392, 4807, 3211, 1607,
    0, -1607, -3211, -4807, -6392, -7961, -9511, -11038,
    -12539, -14009, -15446, -16845, -18204, -19519, -20787, -22004,
    -23169, -24278, -25329, -26318, -27244, -28105, -28897, -29621,
    -30272, -30851, -31356, -31785, -32137, -32412, -32609, -32727,
    -32767, -32727, -32609, -32412, -32137, -31785, -31356, -30851,
    -30272, -29621, -28897, -28105, -27244, -26318, -25329, -24278,
    -23169, -22004, -20787, -19519, -18204, -16845, -15446, -14009,
    -12539, -11038, -9511, -7961, -6392, -4807, -3211, -1607,
};

static int16_t sin_fixed(int x)
{
    int idx = (x >> 3) & 0x7F;
    int frac = x & 7;
    int16_t s0 = sin_lut[idx];
    int16_t s1 = sin_lut[(idx + 1) & 0x7F];
    return s0 + ((s1 - s0) * frac >> 3);
}

/* Generate sine wave into audio_buf, return byte count */
static int gen_sine(int freq, int sample_rate, int channels, int bits, int duration_ms)
{
    int total_samples = sample_rate * duration_ms / 1000;
    int bytes_per_sample = (bits / 8) * channels;
    int total_bytes = total_samples * bytes_per_sample;
    if (total_bytes > AUDIO_BUF_SIZE) total_bytes = AUDIO_BUF_SIZE;
    total_samples = total_bytes / bytes_per_sample;

    for (int i = 0; i < total_samples; i++) {
        int phase = (i * freq * 1024) / sample_rate;
        int16_t sample = sin_fixed(phase & 1023);
        for (int ch = 0; ch < channels; ch++) {
            int off = i * bytes_per_sample + ch * (bits / 8);
            if (bits == 16) {
                audio_buf[off]     = sample & 0xFF;
                audio_buf[off + 1] = (sample >> 8) & 0xFF;
            } else {
                audio_buf[off] = (unsigned char)((sample >> 8) + 128);
            }
        }
    }
    return total_bytes;
}

int ac97_play_wav(const unsigned char *wav_data, int wav_len)
{
    if (!ac97_initialized) return -1;

    int sample_rate = 44100;
    int channels = 2;
    int bits = 16;
    int data_size = 0;
    const unsigned char *data_ptr = 0;

    if (wav_data && wav_len > 44 &&
        wav_data[0]=='R' && wav_data[1]=='I' && wav_data[2]=='F' && wav_data[3]=='F')
    {
        int off = 12;
        while (off + 8 < wav_len) {
            int chunk_size = wav_data[off+4] | (wav_data[off+5]<<8) |
                             (wav_data[off+6]<<16) | (wav_data[off+7]<<24);
            if (wav_data[off]=='f' && wav_data[off+1]=='m' && wav_data[off+2]=='t' && wav_data[off+3]==' ') {
                if (chunk_size >= 16) {
                    channels     = wav_data[off+10] | (wav_data[off+11]<<8);
                    sample_rate  = wav_data[off+12] | (wav_data[off+13]<<8) |
                                   (wav_data[off+14]<<16) | (wav_data[off+15]<<24);
                    bits         = wav_data[off+22] | (wav_data[off+23]<<8);
                }
            } else if (wav_data[off]=='d' && wav_data[off+1]=='a' &&
                       wav_data[off+2]=='t' && wav_data[off+3]=='a') {
                data_size = chunk_size;
                data_ptr = wav_data + off + 8;
            }
            off += 8 + chunk_size;
            if (off & 1) off++;
        }
    }

    if (!data_ptr || data_size <= 0) {
        channels = 2;
    sample_rate = 48000;
        bits = 16;
        data_size = gen_sine(440, sample_rate, channels, bits, 500);
        data_ptr = audio_buf;
    } else {
        if (data_size > 65000) data_size = 65000;
        if (data_size > AUDIO_BUF_SIZE) data_size = AUDIO_BUF_SIZE;
        for (int i = 0; i < data_size; i++)
            audio_buf[i] = data_ptr[i];
    }

    /* Verify BDL alignment */
    if ((uint32_t)(uintptr_t)bdl & 0x3F) return -2;
    if ((uint32_t)(uintptr_t)audio_buf & 0x7F) return -3;

    bdl[0].buf_addr = (uint32_t)(uintptr_t)audio_buf;
    if (data_size > 0xFFFE) data_size = 0xFFFE;
    /* PICB counts 16-bit samples; QEMU reads PICB*2 bytes */
    bdl[0].buf_len = data_size / 2;
    bdl[0].flags = 0x8000;

    /* Bus master reset: ensure CIV=PIV=0 */
    outb(nabmbar + 0x1B, 0x02);
    bm_w8(0x15, 0);              /* PO_LVI = 0 (one entry) */
    bm_w32(0x10, (uint32_t)(uintptr_t)bdl);  /* PO_BDBAR */
    bm_w16(0x16, 0x003F);        /* PO_SR: clear all status */

    outb(nabmbar + 0x1B, 0x01);
    if (!(inb(nabmbar + 0x1B) & 1)) return -5;

    int bcis_ok = 0;
    for (volatile int wait = 0; wait < 20000000; wait++) {
        if (bm_r16(0x16) & 2) { bcis_ok = 1; break; }
        if ((wait & 0xFFFFF) == 0) inb(0x80);
        else asm("pause");
    }

    outb(nabmbar + 0x1B, 0);
    bm_w16(0x16, 0x003F);
    return bcis_ok ? 0 : -4;
}

/* Play raw PCM (48000 Hz, 16-bit, stereo, no WAV header) */
int ac97_play_pcm(const uint8_t *data, int size)
{
    if (!ac97_initialized) return -1;
    ac97_stop();

    if (size > AUDIO_BUF_SIZE) size = AUDIO_BUF_SIZE;
    for (int i = 0; i < size; i++) audio_buf[i] = data[i];

    bdl[0].buf_addr = (uint32_t)(uintptr_t)audio_buf;
    bdl[0].buf_len = size / 2;
    bdl[0].flags = 0x8000;

    outb(nabmbar + 0x1B, 0x02);
    bm_w8(0x15, 0);
    bm_w32(0x10, (uint32_t)(uintptr_t)bdl);
    bm_w16(0x16, 0x003F);

    outb(nabmbar + 0x1B, 0x01);
    if (!(inb(nabmbar + 0x1B) & 1)) return -5;

    int ok = 0;
    for (volatile int w = 0; w < 20000000; w++) {
        if (bm_r16(0x16) & 2) { ok = 1; break; }
        if ((w & 0xFFFFF) == 0) inb(0x80);
        else asm("pause");
    }

    outb(nabmbar + 0x1B, 0);
    bm_w16(0x16, 0x003F);
    return ok ? 0 : -4;
}

int ac97_is_initialized(void) { return ac97_initialized; }

/* Diagnostic: test if DMA makes any progress */
/* Return diagnostic word: high 16 = type, low 16 = data */
int ac97_diag(void)
{
    if (!ac97_initialized) return -1;
    ac97_stop();

    int size = gen_sine(440, 48000, 2, 16, 10);
    if (size > 1024) size = 1024;

    bdl[0].buf_addr = (uint32_t)(uintptr_t)audio_buf;
    bdl[0].buf_len = size / 2;
    bdl[0].flags = 0x8000;

    /* Bus master reset, then program */
    outb(nabmbar + 0x1B, 0x02);
    bm_w32(0x10, (uint32_t)(uintptr_t)bdl);
    bm_w8(0x15, 0);
    uint32_t bdbar_check = inl(nabmbar + 0x10);
    uint8_t lvi_check = inb(nabmbar + 0x15);
    int regs_ok = (bdbar_check == (uint32_t)(uintptr_t)bdl) && (lvi_check == 0);

    bm_w16(0x16, 0x003F);
    uint16_t sr_before = bm_r16(0x16);
    outb(nabmbar + 0x1B, 0x01);
    if (!(inb(nabmbar + 0x1B) & 1)) {
        outb(nabmbar + 0x1B, 0);
        return -5;
    }
    uint16_t sr_after = bm_r16(0x16);
    uint8_t civ_start = inb(nabmbar + 0x14);
    uint16_t picb_start = inw(nabmbar + 0x18);
    int moved = 0;
    for (volatile int wait = 0; wait < 500000; wait++) {
        uint16_t picb = inw(nabmbar + 0x18);
        if (picb != picb_start) { moved = 1; break; }
        asm("pause");
    }

    uint16_t sr = bm_r16(0x16);
    uint16_t picb = inw(nabmbar + 0x18);
    uint8_t civ = inb(nabmbar + 0x14);
    uint8_t cr = inb(nabmbar + 0x1B);
    outb(nabmbar + 0x1B, 0);
    bm_w16(0x16, 0x003F);

    /* Pack result: type=0x10=regs_bad, 0x11=moved+sr, 0x12=stuck+sr */
    if (!regs_ok) return 0x100000 | (bdbar_check & 0xFF) | (lvi_check << 8);
    if (moved) return 0x110000 | (sr & 0xFF) | (civ << 8) | (cr << 12) | (civ_start << 20);
    return 0x120000 | (sr & 0xFF) | (civ << 8) | (cr << 12) | (civ_start << 20) | ((sr_before & 0xFF) << 24);
}

void ac97_stop(void)
{
    if (!ac97_initialized) return;
    outb(nabmbar + 0x1B, 0);
}
