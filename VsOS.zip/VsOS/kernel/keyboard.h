#ifndef KEYBOARD_H
#define KEYBOARD_H

void keyboard_init(void);
int  keyboard_poll(char *c, int *special);

#define KEY_PGUP 0x49
#define KEY_PGDN 0x51

extern int win_r_pressed;

#endif
