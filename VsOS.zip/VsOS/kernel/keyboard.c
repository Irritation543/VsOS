#include "keyboard.h"
#include "../arch/i386/io.h"

static const char sc[] = {
    0,0,'1','2','3','4','5','6','7','8','9','0','-','=',0,0,
    'q','w','e','r','t','y','u','i','o','p','[',']','\n',0,
    'a','s','d','f','g','h','j','k','l',';','\'','`',0,'\\',
    'z','x','c','v','b','n','m',',','.','/',0,'*',0,' ',0,
};

static int shift;
static int win_key;
int win_r_pressed;

void keyboard_init(void)
{
    shift = 0;
    win_key = 0;
    win_r_pressed = 0;
    while (inb(0x64) & 1)
    {
        if (!(inb(0x64) & 0x20))
            inb(0x60);
        else
            inb(0x60);
    }
}

int keyboard_poll(char *c, int *special)
{
    uint8_t status = inb(0x64);
    if (!(status & 1)) return 0;
    if (status & 0x20) return 0;

    uint8_t s = inb(0x60);

    if (s == 0x49) { if (special) *special = KEY_PGUP; return 2; }
    if (s == 0x51) { if (special) *special = KEY_PGDN; return 2; }

    if (s == 0x5B || s == 0x5C) { win_key = 1; return 0; }
    if (s == 0xDB || s == 0xDC) { win_key = 0; return 0; }
    if (win_key && s == 0x13) { win_r_pressed = 1; win_key = 0; return 0; }

    if (s == 0x2A || s == 0x36) { shift = 1; return 0; }
    if (s == 0xAA || s == 0xB6) { shift = 0; return 0; }

    if (s >= 0x80) return 0;

    if (s == 0x0E) { *c = '\b'; return 1; }
    if (s == 0x1C) { *c = '\n'; return 1; }

    if (s >= sizeof(sc)) return 0;
    char ch = sc[s];
    if (!ch) return 0;

    if (shift && ch >= 'a' && ch <= 'z') ch -= 32;
    if (shift && ch >= '1' && ch <= '9') ch = ")!@#$%^&("[ch - '1'];
    if (shift && ch == '0') ch = ')';
    if (shift && ch == '-') ch = '_';
    if (shift && ch == '=') ch = '+';
    if (shift && ch == '[') ch = '{';
    if (shift && ch == ']') ch = '}';
    if (shift && ch == '\\') ch = '|';
    if (shift && ch == ';') ch = ':';
    if (shift && ch == '\'') ch = '"';
    if (shift && ch == ',') ch = '<';
    if (shift && ch == '.') ch = '>';
    if (shift && ch == '/') ch = '?';
    if (shift && ch == '`') ch = '~';

    *c = ch;
    return 1;
}
