#include "rtc.h"
#include "../arch/i386/io.h"

int time_hour_offset = 0;
int time_min_offset = 0;

static int bcd_to_bin(int bcd)
{
    return (bcd & 0x0F) + ((bcd >> 4) * 10);
}

static int cmos_read(int reg)
{
    outb(0x70, reg);
    return inb(0x71);
}

void rtc_init(void)
{
    /* Check if RTC is in BCD or binary mode via Status Register B */
    int stb = cmos_read(0x0B);
    (void)stb;
}

void rtc_read_time(int *h, int *m, int *s)
{
    int stb = cmos_read(0x0B);
    int bin = stb & 4; /* 0 = BCD, 1 = binary */

    int sec = cmos_read(0x00);
    int min = cmos_read(0x02);
    int hour = cmos_read(0x04);

    if (!bin) {
        if (sec) sec = bcd_to_bin(sec);
        if (min) min = bcd_to_bin(min);
        if (hour) hour = bcd_to_bin(hour);
    }

    /* Check 12h mode */
    if (!(stb & 2)) { /* 12h mode */
        int pm = hour & 0x80;
        hour &= 0x7F;
        if (pm) hour += 12;
        if (hour == 12 && !pm) hour = 0;
        if (hour == 24) hour = 12;
    }

    /* Apply offsets */
    min += time_min_offset;
    hour += time_hour_offset;
    while (min >= 60) { min -= 60; hour++; }
    while (min < 0) { min += 60; hour--; }
    while (hour >= 24) hour -= 24;
    while (hour < 0) hour += 24;

    *h = hour;
    *m = min;
    *s = sec;
}

void rtc_read_date(int *d, int *mo, int *y)
{
    int stb = cmos_read(0x0B);
    int bin = stb & 4;

    int day = cmos_read(0x07);
    int mon = cmos_read(0x08);
    int year = cmos_read(0x09);
    int cent = cmos_read(0x32);

    if (!bin) {
        if (day) day = bcd_to_bin(day);
        if (mon) mon = bcd_to_bin(mon);
        if (year) year = bcd_to_bin(year);
        if (cent) cent = bcd_to_bin(cent);
    }

    if (cent) year += cent * 100;
    else year += 2000;

    *d = day;
    *mo = mon;
    *y = year;
}
