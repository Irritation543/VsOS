#include "terminal.h"
#include <stdarg.h>

extern term_t main_term;

void video_putchar(char c) { term_putchar(&main_term, c); }
void video_write(const char *s) { term_write(&main_term, s); }
void video_clear(void) { term_clear(&main_term); }
void video_setcolor(uint8_t fg, uint8_t bg)
{
    uint32_t rgb[] = {0x000000,0x0000AA,0x00AA00,0x00AAAA,0xAA0000,0xAA00AA,0xAAAA00,0xCCCCCC,
                      0x444444,0x0000FF,0x00FF00,0x00FFFF,0xFF0000,0xFF00FF,0xFFFF00,0xFFFFFF};
    term_setcolor(&main_term, rgb[fg & 0xF], rgb[bg & 0xF]);
}

void video_printf(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    for (; *fmt; fmt++)
    {
        if (*fmt != '%') { video_putchar(*fmt); continue; }
        fmt++;
        switch (*fmt)
        {
            case 'd': {
                int v = va_arg(ap, int);
                char b[16]; int i = 0;
                unsigned int u = v < 0 ? -v : v;
                if (v < 0) video_putchar('-');
                do { b[i++] = '0' + u % 10; u /= 10; } while (u);
                while (i) video_putchar(b[--i]);
                break;
            }
            case 's': video_write(va_arg(ap, const char *)); break;
            case 'x': {
                unsigned int v = va_arg(ap, unsigned int);
                char b[16]; int i = 0;
                do { b[i++] = "0123456789ABCDEF"[v % 16]; v /= 16; } while (v);
                while (i) video_putchar(b[--i]);
                break;
            }
            case 'c': video_putchar(va_arg(ap, int)); break;
            case '%': video_putchar('%'); break;
            case 0: goto end;
        }
    }
    end:
    va_end(ap);
}
