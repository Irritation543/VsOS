#include "fb.h"
#include "font.h"
#include "../arch/i386/io.h"

static uint32_t *fb;
static uint32_t bb[800 * 600];
static int use_bb;
static int clip_x1, clip_y1, clip_x2, clip_y2;

int fb_w, fb_h;

void fb_setclip(int x, int y, int w, int h)
{
    clip_x1 = x; clip_y1 = y;
    clip_x2 = x + w; clip_y2 = y + h;
    if (clip_x1 < 0) clip_x1 = 0;
    if (clip_y1 < 0) clip_y1 = 0;
    if (clip_x2 > fb_w) clip_x2 = fb_w;
    if (clip_y2 > fb_h) clip_y2 = fb_h;
}

void fb_resetclip(void)
{
    clip_x1 = 0; clip_y1 = 0;
    clip_x2 = fb_w; clip_y2 = fb_h;
}

static void vbe_write(uint16_t idx, uint16_t val)
{
    outw(0x1CE, idx);
    outw(0x1CF, val);
}

static uint16_t vbe_read(uint16_t idx)
{
    outw(0x1CE, idx);
    return inw(0x1CF);
}

static uint32_t pci_read(uint8_t bus, uint8_t dev, uint8_t func, uint8_t reg)
{
    uint32_t addr = 0x80000000 | ((uint32_t)bus << 16) |
                    ((uint32_t)(dev & 31) << 11) |
                    ((uint32_t)(func & 7) << 8) |
                    (reg & 0xFC);
    outl(0xCF8, addr);
    return inl(0xCFC);
}

static uint32_t find_lfb_addr(void)
{
    for (int dev = 0; dev < 32; dev++)
    {
        uint32_t vid = pci_read(0, dev, 0, 0);
        if ((vid & 0xFFFF) == 0xFFFF) continue;

        uint32_t cc = pci_read(0, dev, 0, 0x08);
        uint8_t cls = (cc >> 24) & 0xFF;
        uint8_t sub = (cc >> 16) & 0xFF;

        if (cls == 0x03 && sub == 0x00)
        {
            uint32_t bar0 = pci_read(0, dev, 0, 0x10);
            if (!(bar0 & 1))
                return bar0 & 0xFFFFFFF0;
        }
    }
    return 0xFD000000;
}

uint32_t *fb_getptr(void)
{
    return use_bb ? bb : fb;
}

void fb_use_backbuffer(void)
{
    use_bb = 1;
}

void fb_use_frontbuffer(void)
{
    use_bb = 0;
}

void fb_present(void)
{
    unsigned int n = (unsigned int)(fb_w * fb_h);
    uint32_t *src = bb;
    uint32_t *dst = fb;
    __asm__ volatile(
        "cld\n"
        "rep movsl\n"
        : "+S"(src), "+D"(dst), "+c"(n)
        :
        : "memory"
    );
}

int fb_init(void)
{
    uint16_t id = vbe_read(0);
    if (id != 0xB0C0 && id != 0xB0C4 && id != 0xB0C5)
        return -1;

    vbe_write(4, 0);
    vbe_write(1, 800);
    vbe_write(2, 600);
    vbe_write(3, 32);
    vbe_write(4, 0x41);

    fb_w = vbe_read(1);
    fb_h = vbe_read(2);
    if (fb_w == 0 || fb_h == 0)
    {
        vbe_write(4, 0);
        vbe_write(1, 640);
        vbe_write(2, 480);
        vbe_write(3, 24);
        vbe_write(4, 0x41);
        fb_w = vbe_read(1);
        fb_h = vbe_read(2);
        if (fb_w == 0 || fb_h == 0) return -1;
    }

    uint32_t phys = find_lfb_addr();
    fb = (uint32_t *)(uintptr_t)phys;
    use_bb = 0;
    fb_resetclip();
    return 0;
}

static uint32_t *target(void)
{
    return use_bb ? bb : fb;
}

void fb_putpixel(int x, int y, uint32_t c)
{
    if (x < clip_x1 || x >= clip_x2 || y < clip_y1 || y >= clip_y2) return;
    target()[y * fb_w + x] = c;
}

void fb_fillrect(int x, int y, int w, int h, uint32_t c)
{
    if (x >= clip_x2 || y >= clip_y2) return;
    if (x + w > clip_x2) w = clip_x2 - x;
    if (y + h > clip_y2) h = clip_y2 - y;
    if (x < clip_x1) { w -= clip_x1 - x; x = clip_x1; }
    if (y < clip_y1) { h -= clip_y1 - y; y = clip_y1; }
    if (w < 0 || h < 0) return;
    uint32_t *buf = target();
    for (int row = y; row < y + h; row++)
    {
        uint32_t *line = &buf[row * fb_w + x];
        int n = w;
        __asm__ volatile(
            "rep stosl\n"
            : "+D"(line), "+c"(n)
            : "a"(c)
            : "memory"
        );
    }
}

void fb_rect3d(int x, int y, int w, int h, uint32_t light, uint32_t dark)
{
    for (int i = 0; i < w; i++)
    {
        fb_putpixel(x + i, y, light);
        fb_putpixel(x + i, y + h - 1, dark);
    }
    for (int i = 0; i < h; i++)
    {
        fb_putpixel(x, y + i, light);
        fb_putpixel(x + w - 1, y + i, dark);
    }
}

void fb_drawchar(int x, int y, char c, uint32_t fg, uint32_t bg)
{
    unsigned char uc = (unsigned char)c;
    uint32_t *buf = target();
    for (int row = 0; row < 8; row++)
    {
        uint8_t bits = font8x8[uc][row];
        for (int col = 0; col < 8; col++)
        {
            uint32_t color = (bits & (1 << (7 - col))) ? fg : bg;
            int px = x + col;
            int py = y + row;
            if (px >= clip_x1 && px < clip_x2 && py >= clip_y1 && py < clip_y2)
                buf[py * fb_w + px] = color;
        }
    }
}

void fb_drawstr(int x, int y, const char *s, uint32_t fg, uint32_t bg)
{
    int cx = x;
    for (; *s; s++)
    {
        if (*s == '\n') { cx = x; y += 10; continue; }
        fb_drawchar(cx, y, *s, fg, bg);
        cx += 9;
    }
}
