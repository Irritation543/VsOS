#include "kernel.h"
#include "fb.h"
#include "keyboard.h"
#include "mouse.h"
#include "wm.h"
#include "desktop.h"
#include "terminal.h"
#include "shell.h"
#include "../arch/i386/io.h"
#include "sound.h"
#include "rtc.h"

term_t main_term;
int shutting_down = 0;

static int dclick_x = -1, dclick_y = -1, dclick_cnt = 0;

static void draw_arrow_at(int mx, int my, uint32_t color)
{
    fb_fillrect(mx, my, 2, 12, color);
    for (int i = 1; i < 8; i++)
    {
        fb_putpixel(mx + i, my + i, color);
        fb_putpixel(mx + i, my + i + 1, color);
    }
    fb_putpixel(mx + 8, my + 8, color);
}

static void draw_h_cursor_at(int mx, int my, uint32_t c)
{
    fb_putpixel(mx - 5, my - 2, c); fb_putpixel(mx - 4, my - 1, c);
    fb_fillrect(mx - 3, my, 7, 1, c);
    fb_putpixel(mx + 4, my - 1, c); fb_putpixel(mx + 5, my - 2, c);
    fb_putpixel(mx - 5, my + 2, c); fb_putpixel(mx - 4, my + 1, c);
    fb_putpixel(mx + 4, my + 1, c); fb_putpixel(mx + 5, my + 2, c);
}

static void draw_v_cursor_at(int mx, int my, uint32_t c)
{
    fb_putpixel(mx - 2, my - 5, c); fb_putpixel(mx - 1, my - 4, c);
    fb_fillrect(mx, my - 3, 1, 7, c);
    fb_putpixel(mx - 1, my + 4, c); fb_putpixel(mx - 2, my + 5, c);
    fb_putpixel(mx + 2, my - 5, c); fb_putpixel(mx + 1, my - 4, c);
    fb_putpixel(mx + 1, my + 4, c); fb_putpixel(mx + 2, my + 5, c);
}

static void draw_hv_cursor_at(int mx, int my, uint32_t c)
{
    draw_h_cursor_at(mx, my, c);
    draw_v_cursor_at(mx, my, c);
}

static void draw_cursor(void)
{
    int mx = mouse_x, my = mouse_y;
    if (mx < 0 || my < 0) return;
    if (cursor_type == CURSOR_H) {
        draw_h_cursor_at(mx, my, 0x000000);
        draw_h_cursor_at(mx, my + 1, 0xFFFFFF);
    } else if (cursor_type == CURSOR_V) {
        draw_v_cursor_at(mx, my, 0x000000);
        draw_v_cursor_at(mx + 1, my, 0xFFFFFF);
    } else if (cursor_type == CURSOR_HV) {
        draw_hv_cursor_at(mx, my, 0x000000);
        draw_hv_cursor_at(mx + 1, my + 1, 0xFFFFFF);
    } else {
        draw_arrow_at(mx - 1, my, 0x000000);
        draw_arrow_at(mx + 1, my, 0x000000);
        draw_arrow_at(mx, my - 1, 0x000000);
        draw_arrow_at(mx, my + 1, 0x000000);
        draw_arrow_at(mx, my, 0xFFFFFF);
    }
}

static void idle_delay(void)
{
    for (int i = 0; i < 300000; i++) asm volatile("pause");
}

void kernel_main(unsigned int magic, void *mb_info)
{
    (void)magic;
    (void)mb_info;

    if (fb_init() != 0) halt();

    keyboard_init();
    mouse_init();
    wm_init();
    desktop_init();
    ac97_init();
    rtc_init();
    shell_init();

    int last_btn = 0;
    int dirty = 1;
    int poll_cnt = 0;

    while (1)
    {
        if (dclick_cnt > 0) dclick_cnt--;

        char c;
        int special = 0;
        int kr = keyboard_poll(&c, &special);
        if (kr == 1)
        {
            if (naming_open())
                naming_key(c);
            else if (run_dialog_open())
                run_dialog_key(c);
            else if (wnd_active && wnd_active->key)
                wnd_active->key(wnd_active, c);
            dirty = 1;
        }
        else if (kr == 2)
        {
            if (wnd_active && wnd_active->key_special)
                wnd_active->key_special(wnd_active, special);
            dirty = 1;
        }

        if (win_r_pressed)
        {
            win_r_pressed = 0;
            run_dialog_toggle();
            dirty = 1;
        }

        if (mouse_poll() > 0) dirty = 1;

        if ((mouse_btn & 1) && !last_btn)
        {
            int was_ictx = ictx_menu_is_open();
            int was_ctx = ctx_menu_is_open();
            int was_naming = naming_open();
            if (was_ictx || was_ctx) desktop_click(mouse_x, mouse_y);
            if (was_ictx && ictx_menu_is_open()) { dirty = 1; }
            else if (was_ctx && ctx_menu_is_open()) { dirty = 1; }
            else if ((was_ictx || was_ctx) && !ctx_menu_is_open() && !ictx_menu_is_open()) { dirty = 1; }
            else if (naming_open() && !was_naming) { dirty = 1; }
            else if (naming_open()) naming_click(mouse_x, mouse_y);
            else if (mouse_y >= fb_h - 36)
                taskbar_click(mouse_x, mouse_y);
            else if (start_menu_open())
                start_menu_click(mouse_x, mouse_y);
            else if (run_dialog_open())
                run_dialog_click(mouse_x, mouse_y);
            else
            {
                wnd_t *w = wm_at(mouse_x, mouse_y);
                if (w) wm_click(mouse_x, mouse_y, 1);
                else
                {
                    desktop_drag_potential(mouse_x, mouse_y);
                    int dx = mouse_x - dclick_x;
                    int dy = mouse_y - dclick_y;
                    if (dclick_cnt > 0 && dx*dx + dy*dy < 200) {
                        desktop_dclick(mouse_x, mouse_y);
                        dclick_cnt = 0;
                    } else {
                        dclick_x = mouse_x;
                        dclick_y = mouse_y;
                        dclick_cnt = 20;
                    }
                }
            }
            dirty = 1;
        }

        /* Right click */
        if ((mouse_btn & 2) && !(last_btn & 2))
        {
            if (mouse_y < fb_h - 36 && !wm_at(mouse_x, mouse_y))
                desktop_rclick(mouse_x, mouse_y);
            dirty = 1;
        }

        wm_mousemove(mouse_x, mouse_y, mouse_btn & 1);
        if (mouse_btn & 1)
        {
            desktop_dragmove(mouse_x, mouse_y, mouse_btn);
        }
        else
        {
            if (wnd_active)
            {
                if (wnd_active->drag) { wnd_active->drag = 0; dirty = 1; }
                if (wnd_active->resize_edge) { wnd_active->resize_edge = 0; dirty = 1; }
            }
            desktop_drag_end();
        }
        last_btn = mouse_btn;

        if (shell_process()) dirty = 1;

        if (shutting_down)
        {
            fb_use_backbuffer();
            fb_fillrect(0, 0, fb_w, fb_h, 0x000000);
            fb_drawstr(fb_w/2 - 54, fb_h/2 - 5, "Shutting down...", 0xAAAAAA, 0x000000);
            fb_present();
            for (volatile int i = 0; i < 5000000; i++) asm volatile("pause");
            outw(0x604, 0x2000);
            outw(0xB004, 0x2000);
            halt();
        }

        if (++poll_cnt < 3) { if (!dirty) continue; }
        poll_cnt = 0;
        if (!dirty) { idle_delay(); continue; }

        fb_use_backbuffer();
        desktop_render();
        wm_render();
        desktop_ovl_render();
        taskbar_render();
        draw_cursor();
        fb_present();
        fb_use_frontbuffer();

        dirty = 0;
    }
}
