#ifndef SCAN_H
#define SCAN_H

void scan_open(void);

#endif
