#ifndef VIDEO_H
#define VIDEO_H

#include <stdint.h>
#include <stdarg.h>

void video_init(void);
void video_putchar(char c);
void video_write(const char *str);
void video_printf(const char *fmt, ...);
void video_clear(void);
void video_setcolor(uint8_t fg, uint8_t bg);

#endif
