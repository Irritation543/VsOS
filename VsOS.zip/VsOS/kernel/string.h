#ifndef STRING_H
#define STRING_H

int strcmp(const char *a, const char *b);
int strlen(const char *s);
int atoi(const char *s);
char *strcpy(char *d, const char *s);

#endif
