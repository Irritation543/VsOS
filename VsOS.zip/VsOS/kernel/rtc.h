#ifndef RTC_H
#define RTC_H

void rtc_init(void);
void rtc_read_time(int *h, int *m, int *s);
void rtc_read_date(int *d, int *mo, int *y);

extern int time_hour_offset;
extern int time_min_offset;

#endif
