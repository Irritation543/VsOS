#ifndef MOUSE_H
#define MOUSE_H

#include <stdint.h>

void mouse_init(void);
int  mouse_poll(void);

extern int mouse_x, mouse_y;
extern uint8_t mouse_btn;

#endif
