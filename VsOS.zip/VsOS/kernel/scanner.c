#include "scanner.h"
#include "wm.h"
#include "fb.h"
#include "string.h"
#include "../arch/i386/io.h"

#define SCAN_N 6

typedef struct {
    const char *name;
    int result;      /* 0=wait, 1=ok, -1=err, 2=testing */
    const char *err;
} sc_entry;

static sc_entry sc_items[SCAN_N];
static int sc_phase;       /* 0=idle, >0 = current test index+1, =SCAN_N+1 = done */
static int sc_expand;      /* expanded error row, -1 = none */
static wnd_t *sc_wnd;
static int sc_frame_delay; /* frames to wait between checks (simulate work) */

static void sc_on_close(wnd_t *w) { (void)w; sc_wnd = 0; }

static void sc_start(void)
{
    sc_phase = 1;
    sc_expand = -1;
    sc_frame_delay = 0;
    sc_items[0].name = "Video (framebuffer)";
    sc_items[1].name = "Audio (AC97)";
    sc_items[2].name = "Window Manager";
    sc_items[3].name = "File System";
    sc_items[4].name = "AC97 registers";
    sc_items[5].name = "Kernel integrity";
    for (int i = 0; i < SCAN_N; i++) {
        sc_items[i].result = 0;
        sc_items[i].err = 0;
    }
}

static void sc_tick(void)
{
    if (sc_phase < 1 || sc_phase > SCAN_N) return;

    if (sc_frame_delay > 0) { sc_frame_delay--; return; }
    sc_frame_delay = 3;

    int i = sc_phase - 1;
    sc_items[i].result = 2;

    switch (i) {
    case 0: { /* Video */
        if (fb_w < 640 || fb_h < 480) { sc_items[i].result = -1; sc_items[i].err = "Resolution too low"; }
        else if ((uint32_t)(uintptr_t)fb_getptr() == 0) { sc_items[i].result = -1; sc_items[i].err = "Framebuffer is NULL"; }
        else sc_items[i].result = 1;
        break;
    }
    case 1: { /* AC97 init */
        extern uint16_t nambar, nabmbar;
        if (!nambar && !nabmbar) { sc_items[i].result = -1; sc_items[i].err = "AC97 not detected via PCI"; }
        else if (inw(nambar + 0) == 0xFFFF) { sc_items[i].result = -1; sc_items[i].err = "AC97 mixer not responding"; }
        else sc_items[i].result = 1;
        break;
    }
    case 2: { /* WM */
        extern int wnd_count;
        if (wnd_count < 0 || wnd_count > 16) { sc_items[i].result = -1; sc_items[i].err = "Window count out of range"; }
        else sc_items[i].result = 1;
        break;
    }
    case 3: { /* Timer/IRQ - check keyboard presence as proxy */
        uint16_t kb = inb(0x64);
        if (kb == 0xFF) { sc_items[i].result = -1; sc_items[i].err = "Keyboard controller not responding"; }
        else sc_items[i].result = 1;
        break;
    }
    case 4: { /* AC97 regs sanity */
        extern uint16_t nabmbar;
        uint16_t sr = inw(nabmbar + 0x16);
        if (sr == 0xFFFF) { sc_items[i].result = -1; sc_items[i].err = "Bus master registers inaccessible"; }
        else sc_items[i].result = 1;
        break;
    }
    case 5: { /* Timer */
        uint32_t tsc_hi, tsc_lo;
        asm volatile("rdtsc" : "=a"(tsc_lo), "=d"(tsc_hi));
        if (tsc_lo == 0 && tsc_hi == 0) { sc_items[i].result = -1; sc_items[i].err = "RDTSC returned zero"; }
        else sc_items[i].result = 1;
        break;
    }
    }

    sc_phase++;
    sc_frame_delay = 5;
}

static void sc_render(wnd_t *w)
{
    sc_tick();

    int x = w->x + 6, y = w->y + TITLE_H + 6;
    if (sc_phase == 0) {
        fb_drawstr(x, y, "Click to start system scan", 0xAAAAAA, 0x1A1A2E);
        return;
    }

    int max_w = (w->w - 16) * 2;
    int progress = (sc_phase - 1) * max_w / SCAN_N;
    if (sc_phase > SCAN_N) progress = max_w;

    fb_fillrect(x, y, max_w, 8, 0x222244);
    fb_fillrect(x, y, progress, 8, 0x00AA00);
    y += 14;

    for (int i = 0; i < SCAN_N; i++) {
        if (sc_items[i].result == 0) continue;
        char icon[4] = "?  ";
        uint32_t col;
        switch (sc_items[i].result) {
            case 1: icon[0]='O'; icon[1]='K'; col=0x00FF00; break;
            case -1: icon[0]='E'; icon[1]='R'; col=0xFF4444; break;
            default: icon[0]='~'; icon[1]=' '; col=0xFFFF00; break;
        }
        fb_drawstr(x + 2, y, icon, col, 0x1A1A2E);
        fb_drawstr(x + 24, y, sc_items[i].name, 0xFFFFFF, 0x1A1A2E);

        if (sc_items[i].result == -1 && i == sc_expand && sc_items[i].err) {
            fb_drawstr(x + 4, y + 12, sc_items[i].err, 0xFF8888, 0x1A1A2E);
            y += 12;
        }
        y += 14;
    }

    if (sc_phase > SCAN_N) {
        int all_ok = 1;
        for (int i = 0; i < SCAN_N; i++)
            if (sc_items[i].result == -1) all_ok = 0;
        y += 4;
        if (all_ok)
            fb_drawstr(x, y, "No errors detected. System OK.", 0x00FF00, 0x1A1A2E);
        else
            fb_drawstr(x, y, "Click an error for details.", 0xFFFF00, 0x1A1A2E);
    }
}

static void sc_click(wnd_t *w, int mx, int my)
{
    (void)w; (void)mx;
    if (sc_phase == 0) { sc_start(); return; }
    if (sc_phase <= SCAN_N) return;

    int y = w->y + TITLE_H + 6 + 14 + 8;
    for (int i = 0; i < SCAN_N; i++) {
        if (sc_items[i].result == 0) continue;
        int h = 14;
        if (sc_items[i].result == -1 && i == sc_expand) h += 12;
        if (my >= y && my < y + 14) {
            if (sc_items[i].result == -1)
                sc_expand = (sc_expand == i) ? -1 : i;
            return;
        }
        y += h;
    }
}

void scan_open(void)
{
    if (sc_wnd) { wm_raise(sc_wnd); return; }
    int win_w = 380;
    int win_h = 260;
    sc_wnd = wm_create((fb_w - win_w) / 2, (fb_h - win_h) / 2 - 30, win_w, win_h, "System Scan");
    if (!sc_wnd) return;
    sc_wnd->render = sc_render;
    sc_wnd->click = sc_click;
    sc_wnd->on_close = sc_on_close;
    sc_phase = 0;
    sc_expand = -1;
    sc_frame_delay = 0;
    wm_raise(sc_wnd);
}
