#ifndef TGA_H
#define TGA_H

#include <stdint.h>

/* Decode TGA image from raw data into 32-bit RGBA pixel buffer.
   Returns 0 on success, -1 on error.
   Out parameters: width, height, actual bpp (24 or 32). */
int tga_decode(const unsigned char *data, int data_len,
               uint32_t *pixels, int max_pixels,
               int *out_w, int *out_h, int *out_bpp);

/* Open a TGA viewer window showing the given image */
void tga_viewer_open(const unsigned char *tga_data, int data_len, const char *title);

/* Open demo viewer with built-in test card */
void tga_viewer_demo(void);

#endif
