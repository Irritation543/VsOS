#ifndef TERMINAL_H
#define TERMINAL_H

#include <stdint.h>
#include "wm.h"

#define TCOLS 100
#define TROWS 40
#define THISTORY 100

typedef struct {
    char c;
    uint32_t fg, bg;
} tcell_t;

typedef struct {
    tcell_t cells[TROWS][TCOLS];
    int cx, cy;
    int cols, rows;
    uint32_t fg, bg;
    char ibuf[2048];
    int ihead, itail;
    int line_ready;
    wnd_t *wnd;
    tcell_t scrollback[THISTORY][TCOLS];
    int scb_wpos;
    int scb_count;
    int scroll_off;
} term_t;

void term_init(term_t *t, wnd_t *w);
void term_putchar(term_t *t, char c);
void term_write(term_t *t, const char *s);
void term_printf(term_t *t, const char *fmt, ...);
void term_clear(term_t *t);
void term_setcolor(term_t *t, uint32_t fg, uint32_t bg);
void term_key(term_t *t, char c);
int  term_readline(term_t *t, char *buf, int max);
void term_render(wnd_t *w);
void terminal_launch(void);

#endif
