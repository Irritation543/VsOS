#include "wm.h"
#include "fb.h"

wnd_t wnd_pool[MAX_WNDS];
int wnd_count = 0;
wnd_t *wnd_active = 0;
int cursor_type = CURSOR_NORMAL;

static int nxt_z = 0;
#define WND_FREE 0x10
#define MIN_W 80
#define MIN_H 40
#define EDGE_W 5

void wm_init(void)
{
    for (int i = 0; i < MAX_WNDS; i++) wnd_pool[i].flags = WND_FREE;
    wnd_count = 0;
    wnd_active = 0;
    nxt_z = 0;
}

wnd_t *wm_create(int x, int y, int w, int h, const char *title)
{
    for (int i = 0; i < MAX_WNDS; i++) {
        if (wnd_pool[i].flags & WND_FREE) {
            wnd_t *p = &wnd_pool[i];
            wnd_count++;
            p->x = x; p->y = y; p->w = w; p->h = h;
            int j;
            for (j = 0; title[j] && j < 63; j++) p->title[j] = title[j];
            p->title[j] = 0;
            p->z = nxt_z++;
            p->flags = WND_CLOSE | WND_MINIMIZE | WND_VISIBLE;
            p->drag = 0;
            p->resize_edge = 0;
            p->render = 0;
            p->key = 0;
            p->key_special = 0;
            p->click = 0;
            p->mousemove = 0;
            p->mousedown = 0;
            p->on_close = 0;
            p->data = 0;
            return p;
        }
    }
    return 0;
}

void wm_destroy(wnd_t *w)
{
    if (!w) return;
    if (wnd_active == w) wnd_active = 0;
    if (!(w->flags & WND_FREE)) wnd_count--;
    w->flags = WND_FREE;
}

void wm_raise(wnd_t *w)
{
    w->z = nxt_z++;
    wnd_active = w;
}

wnd_t *wm_at(int mx, int my)
{
    wnd_t *best = 0;
    int best_z = -1;
    for (int i = 0; i < MAX_WNDS; i++)
    {
        wnd_t *w = &wnd_pool[i];
        if (w->flags & WND_FREE) continue;
        if (!(w->flags & WND_VISIBLE)) continue;
        if (mx >= w->x && mx < w->x + w->w &&
            my >= w->y && my < w->y + w->h &&
            w->z > best_z)
        {
            best = w;
            best_z = w->z;
        }
    }
    return best;
}

void wm_click(int mx, int my, int btn)
{
    (void)btn;
    wnd_t *w = wm_at(mx, my);
    if (!w) { wnd_active = 0; return; }
    wm_raise(w);

    w->drag = 0;
    w->resize_edge = 0;

    /* Title bar: close, minimize, or drag */
    if (my < w->y + TITLE_H)
    {
        if ((w->flags & WND_CLOSE) &&
            mx >= w->x + w->w - 19 && mx <= w->x + w->w - 4 &&
            my >= w->y + 2 && my <= w->y + TITLE_H - 2)
        {
            if (w->on_close) w->on_close(w);
            wm_destroy(w);
            return;
        }
        if ((w->flags & WND_MINIMIZE) &&
            mx >= w->x + w->w - 37 && mx <= w->x + w->w - 22 &&
            my >= w->y + 2 && my <= w->y + TITLE_H - 2)
        {
            wm_minimize(w);
            return;
        }
        w->drag = 1;
        w->dxx = mx - w->x;
        w->dxy = my - w->y;
        return;
    }

    /* Edge resize zone */
    w->resize_edge = 0;
    if (my >= w->y + w->h - EDGE_W) w->resize_edge |= 4;
    if (mx < w->x + EDGE_W)          w->resize_edge |= 1;
    if (mx >= w->x + w->w - EDGE_W)  w->resize_edge |= 2;

    if (w->resize_edge) {
        w->dxx = mx;
        w->dxy = my;
        return;
    }

    wnd_active = w;
    if (w->mousedown) w->mousedown(w, mx, my);
    if (w->click) w->click(w, mx, my);
}

void wm_mousemove(int mx, int my, int btn)
{
    if (!wnd_active) { cursor_type = CURSOR_NORMAL; return; }

    wnd_t *w = wnd_active;

    /* Update cursor for edge hover */
    if (!btn) {
        /* Find window at mouse position */
        wnd_t *hit = wm_at(mx, my);
        if (hit && hit == wnd_active) {
            int on = 0;
            if (my >= w->y + w->h - EDGE_W && my < w->y + w->h) on |= 4;
            if (mx < w->x + EDGE_W && mx >= w->x) on |= 1;
            if (mx >= w->x + w->w - EDGE_W && mx < w->x + w->w) on |= 2;
            if (on & 1 || on & 2) cursor_type = CURSOR_H;
            else if (on & 4) cursor_type = CURSOR_V;
            else cursor_type = CURSOR_NORMAL;
        } else cursor_type = CURSOR_NORMAL;
        return;
    }

    /* Handle resize */
    if (w->resize_edge)
    {
        if (!btn) { w->resize_edge = 0; return; }

        int new_x = w->x, new_y = w->y, new_w = w->w, new_h = w->h;

        if (w->resize_edge & 1) {
            new_x = mx;
            new_w = w->x + w->w - mx;
        }
        if (w->resize_edge & 2) {
            new_w = mx - w->x;
        }
        if (w->resize_edge & 4) {
            new_h = my - w->y;
        }

        if (new_w < MIN_W) {
            if (w->resize_edge & 1) new_x = w->x + w->w - MIN_W;
            new_w = MIN_W;
        }
        if (new_h < MIN_H) new_h = MIN_H;
        if (new_x + new_w > fb_w) {
            if (w->resize_edge & 1) new_x = fb_w - new_w;
            else new_w = fb_w - w->x;
        }
        if (new_x < 0) {
            if (w->resize_edge & 1) { new_w += new_x; new_x = 0; }
            else new_x = 0;
        }
        if (new_y + new_h > fb_h) new_h = fb_h - new_y;
        if (new_h < MIN_H) new_h = MIN_H;

        w->x = new_x; w->y = new_y;
        w->w = new_w; w->h = new_h;
        return;
    }

    /* Handle drag (move) */
    if (w->drag)
    {
        if (!btn) { w->drag = 0; return; }
        w->x = mx - w->dxx;
        w->y = my - w->dxy;
        if (w->x < 0) w->x = 0;
        if (w->y < 0) w->y = 0;
        if (w->x + w->w > fb_w) w->x = fb_w - w->w;
        if (w->y + w->h > fb_h) w->y = fb_h - w->h;
        return;
    }

    /* Content mousemove callback */
    if (w->mousemove)
        w->mousemove(w, mx, my, btn);
}

void wm_key(char c)
{
    if (wnd_active && wnd_active->key)
        wnd_active->key(wnd_active, c);
}

void wm_key_special(int code)
{
    if (wnd_active && wnd_active->key_special)
        wnd_active->key_special(wnd_active, code);
}

void wm_minimize(wnd_t *w)
{
    w->flags &= ~WND_VISIBLE;
    wnd_active = 0;
}

void wm_restore(wnd_t *w)
{
    w->flags |= (WND_VISIBLE | WND_CLOSE | WND_MINIMIZE);
    wm_raise(w);
}

static void draw_title(wnd_t *w)
{
    uint32_t bar = (w == wnd_active) ? 0x000080 : 0x404080;
    fb_fillrect(w->x, w->y, w->w, TITLE_H, bar);
    fb_rect3d(w->x, w->y, w->w, TITLE_H, 0x8080FF, 0x000040);
    fb_drawstr(w->x + 4, w->y + 5, w->title, 0xFFFFFF, bar);

    int btn_x = w->x + w->w - 19;
    if (w->flags & WND_MINIMIZE)
    {
        fb_fillrect(btn_x - 18, w->y + 3, 16, 16, 0xC0C0C0);
        fb_rect3d(btn_x - 18, w->y + 3, 16, 16, 0xFFFFFF, 0x808080);
        fb_fillrect(btn_x - 14, w->y + 12, 8, 2, 0x000000);
    }
    if (w->flags & WND_CLOSE)
    {
        fb_fillrect(btn_x, w->y + 3, 16, 16, 0xC0C0C0);
        fb_rect3d(btn_x, w->y + 3, 16, 16, 0xFFFFFF, 0x808080);
        fb_drawstr(btn_x + 4, w->y + 4, "X", 0x000000, 0xC0C0C0);
    }
}

void wm_render(void)
{
    int order[MAX_WNDS];
    int cnt = 0;
    for (int i = 0; i < MAX_WNDS; i++) {
        wnd_t *w = &wnd_pool[i];
        if (w->flags & WND_FREE) continue;
        if (!(w->flags & WND_VISIBLE)) continue;
        order[cnt++] = i;
    }
    for (int i = 1; i < cnt; i++) {
        int key = order[i];
        int j = i - 1;
        while (j >= 0 && wnd_pool[order[j]].z > wnd_pool[key].z) {
            order[j+1] = order[j];
            j--;
        }
        order[j+1] = key;
    }
    for (int i = 0; i < cnt; i++) {
        wnd_t *w = &wnd_pool[order[i]];
        draw_title(w);
        fb_rect3d(w->x, w->y + TITLE_H, w->w, w->h - TITLE_H, 0xFFFFFF, 0x808080);
        fb_fillrect(w->x + 2, w->y + TITLE_H + 2, w->w - 4, w->h - TITLE_H - 4, 0x1A1A2E);
        fb_setclip(w->x + 2, w->y + TITLE_H + 2, w->w - 4, w->h - TITLE_H - 4);
        if (w->render) w->render(w);
        fb_resetclip();

        /* Resize handle (bottom-right corner) */
        fb_fillrect(w->x + w->w - EDGE_W - 1, w->y + w->h - EDGE_W - 1,
                    EDGE_W + 1, EDGE_W + 1, 0x808080);
        fb_fillrect(w->x + w->w - EDGE_W, w->y + w->h - EDGE_W,
                    EDGE_W, EDGE_W, 0xC0C0C0);
    }
}
