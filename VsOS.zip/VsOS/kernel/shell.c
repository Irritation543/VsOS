#include "shell.h"
#include "terminal.h"
#include "string.h"

extern term_t main_term;

typedef void (*cmd_t)(int, char **);
typedef struct { const char *name, *desc; cmd_t handler; } cmd_entry_t;
extern cmd_entry_t commands[];
extern int commands_count;

static int initialized;

static void parse(char *ln, char **argv, int *argc)
{
    *argc = 0;
    int in = 0;
    for (char *p = ln; *p; p++)
    {
        if (*p == ' ') { *p = 0; in = 0; }
        else { if (!in) { argv[(*argc)++] = p; in = 1; } }
    }
    argv[*argc] = 0;
}

void shell_init(void)
{
    initialized = 0;
}

int shell_process(void)
{
    if (!main_term.wnd || !(main_term.wnd->flags)) return 0;

    int changed = 0;
    if (!initialized)
    {
        term_write(&main_term, "VsOS GUI v0.1\n");
        term_write(&main_term, "Type 'help' for commands\n\n");
        initialized = 1;
        changed = 1;
    }

    char buf[128];
    int len = term_readline(&main_term, buf, sizeof(buf));
    if (len <= 0) return changed;

    char *argv[32];
    int argc;
    parse(buf, argv, &argc);
    if (argc == 0) return changed + 1;

    int found = 0;
    for (int i = 0; i < commands_count; i++)
    {
        if (strcmp(argv[0], commands[i].name) == 0)
        {
            commands[i].handler(argc, argv);
            found = 1;
            changed = 1;
            break;
        }
    }
    if (!found)
    {
        term_write(&main_term, "Unknown: ");
        term_write(&main_term, argv[0]);
        term_write(&main_term, "\n");
        changed = 1;
    }
    return changed + 1;
}
