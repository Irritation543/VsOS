#include "notepad.h"
#include "wm.h"
#include "fb.h"
#include "string.h"

#define NP_BUF 4096
#define NP_ROWS 20
#define NP_COLS 50

/* Filesystem tree from explorer (simplified access) */
/* We reuse the known folder names */
#define MAX_FOLDERS 10
static const char *root_folders[MAX_FOLDERS] = {
    "Program Files", "Windows", "Users", "System32", "Temp", 0
};

typedef struct {
    wnd_t *wnd;
    char *ext_content;
    int *ext_len;
    char filename[32];
    char buf[NP_BUF];
    int len;
    int cursor;
    int file_menu;
    int dirty;

    /* Save As state */
    wnd_t *savedlg;
    int saveas_folder_idx;

    /* Confirm dialog state */
    wnd_t *confirm;
} np_t;

static np_t np;

/* Forward decls */
static void np_close_confirm(int yes);

static void np_render_confirm(wnd_t *w)
{
    int x = w->x + 8, y = w->y + TITLE_H + 10;
    fb_drawstr(x, y, "Are you sure?", 0xFFFFFF, 0x1A1A2E);

    /* Yes button */
    fb_fillrect(x, y + 28, 50, 20, 0xC0C0C0);
    fb_rect3d(x, y + 28, 50, 20, 0xFFFFFF, 0x808080);
    fb_drawstr(x + 8, y + 32, "Yes", 0x000000, 0xC0C0C0);

    /* No button */
    fb_fillrect(x + 60, y + 28, 50, 20, 0xC0C0C0);
    fb_rect3d(x + 60, y + 28, 50, 20, 0xFFFFFF, 0x808080);
    fb_drawstr(x + 70, y + 32, "No", 0x000000, 0xC0C0C0);
}

static void np_click_confirm(wnd_t *w, int mx, int my)
{
    int x = w->x + 8, y = w->y + TITLE_H + 38;
    if (my >= y && my < y + 20) {
        if (mx >= x && mx < x + 50) { np_close_confirm(1); return; }
        if (mx >= x + 60 && mx < x + 110) { np_close_confirm(0); return; }
    }
}

static void np_confirm_on_close(wnd_t *w)
{
    (void)w;
    np.confirm = 0;
}

static void np_close_confirm(int yes)
{
    if (np.confirm) {
        if (np.confirm->on_close) np.confirm->on_close(np.confirm);
        wm_destroy(np.confirm);
        np.confirm = 0;
    }
    if (yes) {
        /* Close notepad */
        if (np.wnd) {
            np.wnd->flags = 0;
            np.wnd = 0;
        }
    }
}

static void np_save(void);

static void np_render_savedlg(wnd_t *w)
{
    int x = w->x + 8, y = w->y + TITLE_H + 8;
    fb_drawstr(x, y, "Save to folder:", 0xFFFFFF, 0x1A1A2E); y += 16;

    /* Path bar */
    fb_fillrect(x, y, w->w - 16, 14, 0xFFFFFF);
    fb_rect3d(x, y, w->w - 16, 14, 0x808080, 0xFFFFFF);
    fb_drawstr(x + 4, y + 2, "C:\\", 0x000000, 0xFFFFFF);
    y += 20;

    /* Folder list */
    for (int i = 0; root_folders[i]; i++) {
        int iy = y + i * 18;
        uint32_t bg = (i == np.saveas_folder_idx) ? 0x000080 : 0x1A1A2E;
        uint32_t fg = (i == np.saveas_folder_idx) ? 0xFFFFFF : 0xFFFF80;
        fb_fillrect(x, iy, w->w - 16, 16, bg);
        fb_fillrect(x + 2, iy + 2, 12, 12, 0xFFFF00);
        fb_rect3d(x + 2, iy + 2, 12, 12, 0xFFFF80, 0x808000);
        fb_drawstr(x + 18, iy + 2, root_folders[i], fg, bg);
    }

    /* Save button */
    int bx = x + w->w - 70;
    int by = w->y + w->h - 28;
    fb_fillrect(bx, by, 54, 20, 0xC0C0C0);
    fb_rect3d(bx, by, 54, 20, 0xFFFFFF, 0x808080);
    fb_drawstr(bx + 8, by + 4, "Save", 0x000000, 0xC0C0C0);
}

static void np_click_savedlg(wnd_t *w, int mx, int my)
{
    int x = w->x + 8, y = w->y + TITLE_H + 44;
    for (int i = 0; root_folders[i]; i++) {
        int iy = y + i * 18;
        if (mx >= x && mx < x + w->w - 16 && my >= iy && my < iy + 16) {
            np.saveas_folder_idx = i;
            return;
        }
    }
    /* Save button */
    int bx = w->x + w->w - 62;
    int by = w->y + w->h - 28;
    if (mx >= bx && mx < bx + 54 && my >= by && my < by + 20) {
        np_save();
        if (np.savedlg) {
            if (np.savedlg->on_close) np.savedlg->on_close(np.savedlg);
            wm_destroy(np.savedlg);
            np.savedlg = 0;
        }
    }
}

static void np_savedlg_on_close(wnd_t *w) { (void)w; np.savedlg = 0; }

static void np_save(void)
{
    if (np.ext_content && np.ext_len) {
        int max_save = *np.ext_len;
        if (max_save > NP_BUF) max_save = NP_BUF;
        int i;
        for (i = 0; i < np.len && i < max_save - 1; i++)
            np.ext_content[i] = np.buf[i];
        np.ext_content[i] = 0;
        *np.ext_len = i;
    }
    np.file_menu = 0;
    np.dirty = 0;
}

static void np_render(wnd_t *w)
{
    int x = w->x + 4, y = w->y + TITLE_H + 4;
    int cw = w->w - 8;

    fb_fillrect(x, y, cw, 18, 0xC0C0C0);
    fb_rect3d(x, y, cw, 18, 0xFFFFFF, 0x808080);
    uint32_t fg = np.file_menu ? 0xFFFFFF : 0x000000;
    uint32_t bg = np.file_menu ? 0x000080 : 0xC0C0C0;
    fb_fillrect(x + 2, y + 2, 36, 14, bg);
    fb_drawstr(x + 6, y + 4, "File", fg, bg);
    y += 22;

    if (np.file_menu) {
        int mx2 = w->x + 6, my2 = w->y + TITLE_H + 20;
        fb_fillrect(mx2, my2, 110, 66, 0xD4D0C8);
        fb_rect3d(mx2, my2, 110, 66, 0xFFFFFF, 0x808080);
        const char *items[] = {"Save", "Save As...", "Don't Save"};
        for (int i = 0; i < 3; i++) {
            fb_fillrect(mx2 + 2, my2 + 2 + i*22, 106, 20, 0xD4D0C8);
            fb_drawstr(mx2 + 6, my2 + 5 + i*22, items[i], 0x000000, 0xD4D0C8);
        }
    }

    fb_fillrect(x, y, cw, w->h - TITLE_H - 30, 0xFFFFFF);
    fb_rect3d(x, y, cw, w->h - TITLE_H - 30, 0x808080, 0xFFFFFF);

    int ly = y + 4;
    for (int ci = 0; ci < np.len && ly < y + w->h - TITLE_H - 54; ci++) {
        int cx = x + 4;
        while (ci < np.len && np.buf[ci] != '\n' && cx < x + cw - 10) {
            char ch2 = np.buf[ci];
            if (ch2 >= 32) { char s[2] = {ch2, 0}; fb_drawstr(cx, ly, s, 0x000000, 0xFFFFFF); cx += 9; }
            ci++;
        }
        ly += 12;
    }

    if (!np.file_menu) {
        int cx = x + 4 + (np.cursor % NP_COLS) * 9;
        int cy = y + 4 + (np.cursor / NP_COLS) * 12;
        fb_fillrect(cx, cy, 1, 10, 0x000000);
    }
}

static void np_key(wnd_t *w, char c)
{
    (void)w;
    if (np.file_menu) { if (c == 27) np.file_menu = 0; return; }
    if (c == '\b') { if (np.cursor > 0) { np.cursor--; np.len--; np.dirty = 1; } return; }
    if (c == '\n') { if (np.len < NP_BUF - 1) { np.buf[np.len++] = '\n'; np.cursor = np.len; np.dirty = 1; } return; }
    if (c >= 32 && c < 127 && np.len < NP_BUF - 1) { np.buf[np.len++] = c; np.cursor = np.len; np.dirty = 1; }
}

static void np_click(wnd_t *w, int mx, int my)
{
    int mx_off = mx - (w->x + 6);
    int my_off = my - (w->y + TITLE_H + 20);

    if (np.file_menu) {
        if (mx_off >= 0 && mx_off < 110 && my_off >= 0 && my_off < 66) {
            int idx = my_off / 22;
            if (idx == 0) { np_save(); }
            else if (idx == 1) {
                np.file_menu = 0;
                if (!np.savedlg) {
                    np.saveas_folder_idx = 0;
                    np.savedlg = wm_create(w->x + 40, w->y + 40, 240, 200, "Save As");
                    if (np.savedlg) {
                        np.savedlg->render = np_render_savedlg;
                        np.savedlg->click = np_click_savedlg;
                        np.savedlg->on_close = np_savedlg_on_close;
                        wm_raise(np.savedlg);
                    }
                }
            }
            else if (idx == 2) {
                np.file_menu = 0;
                if (!np.confirm) {
                    np.confirm = wm_create(fb_w/2 - 80, fb_h/2 - 40, 160, 90, "Confirm");
                    if (np.confirm) {
                        np.confirm->render = np_render_confirm;
                        np.confirm->click = np_click_confirm;
                        np.confirm->on_close = np_confirm_on_close;
                        wm_raise(np.confirm);
                    }
                }
            }
            return;
        }
        np.file_menu = 0;
        return;
    }

    if (my >= w->y + TITLE_H + 4 && my < w->y + TITLE_H + 22) {
        if (mx >= w->x + 6 && mx < w->x + 42) { np.file_menu = !np.file_menu; return; }
    }

    int tx = w->x + 4, ty = w->y + TITLE_H + 26;
    if (my >= ty) {
        int row = (my - ty) / 12;
        int col = (mx - tx) / 9;
        if (col < 0) col = 0;
        if (col > NP_COLS) col = NP_COLS;
        int pos = row * NP_COLS + col;
        if (pos > np.len) pos = np.len;
        np.cursor = pos;
    }
}

static void np_on_close(wnd_t *w)
{
    (void)w;
    np.wnd = 0;
}

wnd_t *notepad_open(const char *filename, char *content, int *content_len)
{
    if (np.wnd && (np.wnd->flags & WND_VISIBLE)) { wm_raise(np.wnd); return np.wnd; }
    if (np.wnd) { wm_restore(np.wnd); return np.wnd; }

    np.wnd = wm_create(200, 100, NP_COLS * 9 + 16, NP_ROWS * 12 + 60, filename);
    if (!np.wnd) return 0;
    np.wnd->render = np_render;
    np.wnd->key = np_key;
    np.wnd->click = np_click;
    np.wnd->on_close = np_on_close;
    np.wnd->data = &np;

    np.ext_content = content;
    np.ext_len = content_len;
    np.file_menu = 0;
    np.dirty = 0;
    np.savedlg = 0;
    np.confirm = 0;
    int i;
    for (i = 0; filename[i] && i < 31; i++) np.filename[i] = filename[i];
    np.filename[i] = 0;

    if (content && content_len && *content_len > 0) {
        np.len = *content_len;
        if (np.len > NP_BUF - 1) np.len = NP_BUF - 1;
        for (i = 0; i < np.len; i++) np.buf[i] = content[i];
    } else {
        np.len = 0;
    }
    np.cursor = np.len;

    return np.wnd;
}
