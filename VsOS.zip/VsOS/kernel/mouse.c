#include "mouse.h"
#include "fb.h"
#include "settings.h"
#include "../arch/i386/io.h"

int mouse_x = 400, mouse_y = 300;
uint8_t mouse_btn = 0;

static uint8_t cycle = 0;
static uint8_t buf[3];

static void wait_write(void)
{
    uint32_t t = 100000;
    while (t-- && (inb(0x64) & 2));
}

static uint8_t wait_read(void)
{
    uint32_t t = 100000;
    while (t-- && !(inb(0x64) & 1));
    return inb(0x60);
}

static void mouse_write(uint8_t b)
{
    wait_write();
    outb(0x64, 0xD4);
    wait_write();
    outb(0x60, b);
}

void mouse_init(void)
{
    wait_write(); outb(0x64, 0xA8);
    wait_write(); outb(0x64, 0x20);
    wait_write();
    uint8_t s = inb(0x60) | 2;
    wait_write(); outb(0x64, 0x60);
    wait_write(); outb(0x60, s);
    mouse_write(0xF6);
    wait_read();
    mouse_write(0xF4);
    wait_read();
}

int mouse_poll(void)
{
    if (!(inb(0x64) & 0x20)) return 0;

    uint8_t b = inb(0x60);
    buf[cycle++] = b;

    if (cycle == 3)
    {
        cycle = 0;
        if (buf[0] & 0x08)
        {
            static int dx_acc = 0, dy_acc = 0;
            int raw_dx = (int8_t)(buf[1]);
            int raw_dy = (int8_t)(buf[2]);
            dx_acc += raw_dx * mouse_speed;
            dy_acc += raw_dy * mouse_speed;
            int dx = dx_acc / 100;
            int dy = dy_acc / 100;
            dx_acc -= dx * 100;
            dy_acc -= dy * 100;
            mouse_x += dx;
            mouse_y -= dy;
            if (mouse_x < 0) mouse_x = 0;
            if (mouse_y < 0) mouse_y = 0;
            if (mouse_x >= fb_w) mouse_x = fb_w - 1;
            if (mouse_y >= fb_h) mouse_y = fb_h - 1;
            mouse_btn = buf[0] & 7;
            return 3;
        }
    }
    return 1;
}
