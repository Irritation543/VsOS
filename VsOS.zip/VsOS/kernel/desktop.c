#include "desktop.h"
#include "fb.h"
#include "wm.h"
#include "terminal.h"
#include "explorer.h"
#include "notepad.h"
#include "settings.h"
#include "string.h"
#include "wallpaper.h"
#include "tga.h"
#include "rtc.h"

#define TH 36

extern wnd_t wnd_pool[];

/* ===== Desktop color ===== */
static uint32_t desk_color = 0x008080;
static int desk_wallpaper = -1;  /* -1 = solid color, 0+ = wallpaper index */

/* ===== Start menu ===== */
static int start_open = 0;
#define SM_W 180
#define SM_H 200
#define SM_ICON_W 22
#define SM_MENU_ITEMS 5

/* ===== Run dialog ===== */
static int run_open = 0;
static char run_buf[32];
static int run_len = 0;
#define RUN_W 280
#define RUN_H 90

/* ===== Naming dialog ===== */
static int naming_active = 0;
static char naming_buf[32];
static int naming_len = 0;
static void (*naming_cb)(const char *) = 0;
#define NAME_W 260
#define NAME_H 70

/* ===== Right-click context menu ===== */
static int ctx_open = 0;
static int ctx_x, ctx_y;
static int ctx_sub = 0;
#define CTX_W 130
#define CTX_ITEM_H 22
#define CTX_SUB_W 120

/* ===== Icon context menu ===== */
static int ictx_open = 0;
static int ictx_di = -1;
static int ictx_x, ictx_y;
static int ictx_rename_di = -1;
#define ICTX_W 120
#define ICTX_ITEM_H 22
#define ICTX_ITEMS 3

/* ===== Desktop items ===== */
#define MAX_DI 32
#define DI_APP 0
#define DI_FOLDER 1
#define DI_FILE 2
#define DI_INI 3
#define FILE_BUF 512

typedef struct {
    int x, y;
    char name[32];
    int type;
    void (*click)(void);
    char content[FILE_BUF];
    int content_len;
} ditem_t;

static ditem_t ditems[MAX_DI];
static int di_cnt = 0;

/* ===== Trash ===== */
#define MAX_TRASH 32
static ditem_t trash_items[MAX_TRASH];
static int trash_cnt = 0;
static wnd_t *trash_wnd = 0;
static wnd_t *trash_confirm_wnd = 0;

static void make_unique_name(char *buf, int bufsize, const char *base)
{
    int i;
    for (i = 0; base[i] && i < bufsize - 1; i++) buf[i] = base[i];
    buf[i] = 0;
    int num = 0;
    while (1) {
        int dup = 0;
        for (int j = 0; j < di_cnt; j++) {
            if (strcmp(ditems[j].name, buf) == 0) { dup = 1; break; }
        }
        if (!dup) return;
        num++;
        int len = strlen(base);
        int pos = len;
        if (pos < bufsize - 1) buf[pos++] = ' ';
        char tmp[16]; int ti = 0;
        int n = num;
        while (n > 0) { tmp[ti++] = '0' + n % 10; n /= 10; }
        for (int j = ti - 1; j >= 0 && pos < bufsize - 1; j--) buf[pos++] = tmp[j];
        buf[pos] = 0;
    }
}

/* ===== Desktop grid ===== */
#define GRID_X0 40
#define GRID_Y0 40
#define GRID_DX 70
#define GRID_DY 90
#define GRID_ICON_W 48
#define GRID_ICON_H 62

/* ===== Icon drag state ===== */
static int drag_di = -1;
static int drag_off_x, drag_off_y;
static int drag_pot = -1;
static int drag_start_x, drag_start_y;
#define DRAG_THRESH 8

static void grid_snap(int *x, int *y)
{
    int col = (*x - GRID_X0 + GRID_DX/2) / GRID_DX;
    int row = (*y - GRID_Y0 + GRID_DY/2) / GRID_DY;
    if (col < 0) col = 0;
    if (row < 0) row = 0;
    if (row * GRID_DY + GRID_Y0 + GRID_ICON_H > fb_h - TH) row = (fb_h - TH - GRID_Y0 - GRID_ICON_H) / GRID_DY;
    *x = GRID_X0 + col * GRID_DX;
    *y = GRID_Y0 + row * GRID_DY;
}

static int add_di(int x, int y, const char *name, int type, void (*click)(void))
{
    if (di_cnt >= MAX_DI) return -1;
    int i = di_cnt++;
    ditems[i].x = x; ditems[i].y = y;
    int j;
    for (j = 0; name[j] && j < 31; j++) ditems[i].name[j] = name[j];
    ditems[i].name[j] = 0;
    ditems[i].type = type;
    ditems[i].click = click;
    ditems[i].content[0] = 0;
    ditems[i].content_len = 0;
    return i;
}

/* Forward decls */
static void shutdown_action(void);
static void error_render(wnd_t *w);
static void error_click(wnd_t *w, int mx, int my);
static void create_ini_cb(const char *name);

/* ===== Public API ===== */
int start_menu_open(void) { return start_open; }
int run_dialog_open(void) { return run_open; }
void run_dialog_toggle(void) { run_open = !run_open; if (!run_open) { run_len = 0; run_buf[0] = 0; } }
int naming_open(void) { return naming_active; }

/* ===== About window ===== */
static wnd_t *about_wnd = 0;

static void about_render(wnd_t *w)
{
    int x = w->x + 8, y = w->y + TITLE_H + 8;
    uint32_t bg = 0x1A1A2E;
    fb_drawstr(x, y, "VsOS v0.1", 0xFFFFFF, bg); y += 14;
    fb_drawstr(x, y, "GUI Operating System", 0xCCCCCC, bg); y += 12;
    fb_drawstr(x, y, "800x600 32-bit VBE", 0xCCCCCC, bg); y += 12;
    fb_drawstr(x, y, "PS/2 keyboard & mouse", 0xCCCCCC, bg); y += 12;
    fb_drawstr(x, y, "Window manager", 0xCCCCCC, bg); y += 12;
    fb_drawstr(x, y, "Terminal emulator", 0xCCCCCC, bg); y += 12;
    fb_drawstr(x, y, "Shell with commands", 0xCCCCCC, bg); y += 12;
}

static void about_on_close(wnd_t *w) { (void)w; about_wnd = 0; }

static void launch_about(void)
{
    if (about_wnd) {
        if (about_wnd->flags & WND_VISIBLE) { wm_raise(about_wnd); return; }
        wm_restore(about_wnd); return;
    }
    about_wnd = wm_create(100, 80, 260, 150, "About");
    if (!about_wnd) return;
    about_wnd->render = about_render;
    about_wnd->key = 0;
    about_wnd->on_close = about_on_close;
}

extern int shutting_down;
static void shutdown_action(void) { shutting_down = 1; }
static void start_toggle(void) { start_open = !start_open; }

/* ===== Start menu ===== */
typedef struct {
    const char *label;
    void (*draw_icon)(int x, int y);
    void (*action)(void);
} sm_item_t;

static void sm_draw_about(int x, int y)
{
    fb_fillrect(x + 2, y + 3, 12, 12, 0xFFFFF0);
    fb_fillrect(x + 5, y + 6, 6, 1, 0xAAAAAA);
    fb_fillrect(x + 5, y + 9, 4, 1, 0xAAAAAA);
    fb_fillrect(x + 5, y + 12, 5, 1, 0xAAAAAA);
}

static void sm_draw_shutdown(int x, int y)
{
    fb_fillrect(x + 1, y + 1, 14, 14, 0x802020);
    fb_rect3d(x + 1, y + 1, 14, 14, 0xFF6060, 0x400000);
    fb_drawstr(x + 4, y + 4, "X", 0xFFFFFF, 0x802020);
}

static void sm_draw_notepad(int x, int y)
{
    fb_fillrect(x + 2, y + 2, 12, 12, 0xEEEEEE);
    fb_rect3d(x + 2, y + 2, 12, 12, 0xFFFFFF, 0x808080);
    fb_fillrect(x + 4, y + 5, 8, 1, 0x888888);
    fb_fillrect(x + 4, y + 8, 6, 1, 0x888888);
    fb_fillrect(x + 4, y + 11, 7, 1, 0x888888);
}

static void sm_draw_settings(int x, int y)
{
    fb_fillrect(x + 1, y + 1, 14, 14, 0x404040);
    fb_fillrect(x + 3, y + 3, 10, 10, 0x808080);
    fb_fillrect(x + 5, y + 5, 6, 6, 0xC0C0C0);
}

static void launch_notepad(void)
{
    notepad_open("Untitled", 0, 0);
}

static void launch_settings(void)
{
    settings_open();
}

static sm_item_t sm_items[SM_MENU_ITEMS] = {
    {"About",       sm_draw_about,    launch_about},
    {"Notepad",     sm_draw_notepad,  launch_notepad},
    {"Settings",    sm_draw_settings, launch_settings},
    {0,             0,                0},
    {"Shut Down...",sm_draw_shutdown, shutdown_action},
};

static int sm_item_y(int idx)
{
    if (idx == 4) return SM_H - 36;
    return 34 + idx * 40;
}

void start_menu_click(int mx, int my)
{
    if (!start_open) return;
    int sy = fb_h - TH - SM_H;
    int sx = 2;
    if (mx < sx || mx >= sx + SM_W || my < sy || my >= sy + SM_H) {
        start_open = 0; return;
    }
    for (int i = 0; i < SM_MENU_ITEMS; i++) {
        if (!sm_items[i].label) continue;
        int iy = sy + sm_item_y(i);
        if (my >= iy && my < iy + 28) {
            start_open = 0;
            if (sm_items[i].action) sm_items[i].action();
            return;
        }
    }
    start_open = 0;
}

/* ===== Run dialog ===== */
static void run_dialog_execute(void);

void run_dialog_click(int mx, int my)
{
    if (!run_open) return;
    int sy = fb_h - TH - RUN_H;
    int sx = 2;
    if (mx < sx || mx >= sx + RUN_W || my < sy || my >= sy + RUN_H) {
        run_open = 0; run_len = 0; run_buf[0] = 0; return;
    }
    if (mx >= sx + RUN_W - 66 && mx <= sx + RUN_W - 6 &&
        my >= sy + RUN_H - 28 && my <= sy + RUN_H - 8)
        run_dialog_execute();
}

void run_dialog_key(char c)
{
    if (!run_open) return;
    if (c == '\b') { if (run_len > 0) run_buf[--run_len] = 0; }
    else if (c == '\n') { run_dialog_execute(); }
    else if (c == 27) { run_open = 0; run_len = 0; run_buf[0] = 0; }
    else if (c >= 32 && c < 127 && run_len < 30) { run_buf[run_len++] = c; run_buf[run_len] = 0; }
}

static int str_eq(const char *a, const char *b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void error_click(wnd_t *w, int mx, int my)
{
    int bx = w->x + w->w - 46;
    int by = w->y + w->h - 26;
    if (mx >= bx && mx < bx + 38 && my >= by && my < by + 18) {
        if (w->on_close) w->on_close(w);
        wm_destroy(w);
    }
}

static void error_render(wnd_t *w)
{
    fb_drawstr(w->x + 10, w->y + TITLE_H + 10, "Unknown command", 0xFF6666, 0x1A1A2E);
    fb_drawstr(w->x + 10, w->y + TITLE_H + 22, "Use 'cmd' for terminal", 0xAAAAAA, 0x1A1A2E);
    int bx = w->x + w->w - 46;
    int by = w->y + w->h - 26;
    fb_fillrect(bx, by, 38, 18, 0xC0C0C0);
    fb_rect3d(bx, by, 38, 18, 0xFFFFFF, 0x808080);
    fb_drawstr(bx + 10, by + 4, "OK", 0x000000, 0xC0C0C0);
}

static void run_dialog_execute(void)
{
    if (run_len == 0) return;
    run_open = 0; run_buf[run_len] = 0;
    if (str_eq(run_buf, "cmd")) { run_len = 0; run_buf[0] = 0; terminal_launch(); }
    else {
        wnd_t *err = wm_create(fb_w/2 - 120, fb_h/2 - 40, 240, 80, "Error");
        if (err) { err->render = error_render; err->click = error_click; err->key = 0; }
        run_len = 0; run_buf[0] = 0;
    }
}

/* ===== Naming dialog ===== */
void naming_start(const char *initial, void (*done)(const char *))
{
    naming_active = 1;
    naming_len = 0;
    while (initial[naming_len] && naming_len < 30) {
        naming_buf[naming_len] = initial[naming_len];
        naming_len++;
    }
    naming_buf[naming_len] = 0;
    naming_cb = done;
}

void naming_cancel(void) { naming_active = 0; naming_cb = 0; }

void naming_key(char c)
{
    if (!naming_active) return;
    if (c == '\b') { if (naming_len > 0) naming_buf[--naming_len] = 0; }
    else if (c == '\n') { if (naming_cb && naming_len > 0) naming_cb(naming_buf); naming_active = 0; naming_cb = 0; }
    else if (c == 27) { naming_active = 0; naming_cb = 0; }
    else if (c >= 32 && c < 127 && naming_len < 30) { naming_buf[naming_len++] = c; naming_buf[naming_len] = 0; }
}

void naming_click(int mx, int my)
{
    if (!naming_active) return;
    int sx = (fb_w - NAME_W) / 2;
    int sy = (fb_h - NAME_H) / 2;
    if (mx < sx || mx >= sx + NAME_W || my < sy || my >= sy + NAME_H) {
        if (naming_len > 0 && naming_cb) naming_cb(naming_buf);
        naming_active = 0; naming_cb = 0; return;
    }
    int bx = sx + NAME_W - 46;
    int by = sy + NAME_H - 26;
    if (mx >= bx && mx < bx + 38 && my >= by && my < by + 18) {
        if (naming_cb && naming_len > 0) naming_cb(naming_buf);
        naming_active = 0; naming_cb = 0;
    }
}

void naming_render(void)
{
    if (!naming_active) return;
    int sx = (fb_w - NAME_W) / 2;
    int sy = (fb_h - NAME_H) / 2;
    fb_fillrect(sx, sy, NAME_W, NAME_H, 0xD4D0C8);
    fb_rect3d(sx, sy, NAME_W, NAME_H, 0xFFFFFF, 0x808080);
    fb_fillrect(sx + 2, sy + 2, NAME_W - 4, 18, 0x000080);
    fb_rect3d(sx + 2, sy + 2, NAME_W - 4, 18, 0x6666CC, 0x000040);
    fb_drawstr(sx + 6, sy + 5, "Name", 0xFFFFFF, 0x000080);
    fb_drawstr(sx + 8, sy + 26, "Name:", 0x000000, 0xD4D0C8);
    fb_fillrect(sx + 50, sy + 24, NAME_W - 60, 18, 0xFFFFFF);
    fb_rect3d(sx + 50, sy + 24, NAME_W - 60, 18, 0x808080, 0xFFFFFF);
    fb_drawstr(sx + 53, sy + 26, naming_buf, 0x000000, 0xFFFFFF);
    int cx = sx + 53 + naming_len * 9;
    if (cx < sx + NAME_W - 15) fb_fillrect(cx, sy + 25, 1, 16, 0x000000);
    int bx = sx + NAME_W - 46;
    fb_fillrect(bx, sy + NAME_H - 26, 38, 18, 0xC0C0C0);
    fb_rect3d(bx, sy + NAME_H - 26, 38, 18, 0xFFFFFF, 0x808080);
    fb_drawstr(bx + 6, sy + NAME_H - 22, "OK", 0x000000, 0xC0C0C0);
}

/* ===== Desktop folder/file callbacks ===== */
static void create_folder_cb(const char *name);
static void create_file_cb(const char *name);

/* ===== Right-click context menu ===== */
void desktop_rclick(int mx, int my)
{
    ctx_open = 0; ctx_sub = 0; ictx_rename_di = -1;
    for (int i = 0; i < di_cnt; i++) {
        if (mx >= ditems[i].x && mx < ditems[i].x + GRID_ICON_W &&
            my >= ditems[i].y && my < ditems[i].y + GRID_ICON_H) {
            ictx_di = i;
            ictx_x = mx;
            ictx_y = my;
            ictx_open = 1;
            return;
        }
    }
    ctx_x = mx; ctx_y = my;
    ctx_open = 1;
    ctx_sub = 0;
}

static void ctx_click(int mx, int my)
{
    if (!ctx_open) return;
    int x = ctx_x, y = ctx_y;
    int total_w = CTX_W + (ctx_sub ? CTX_SUB_W : 0);
    if (mx < x || mx >= x + total_w || my < y || my >= y + 2*CTX_ITEM_H + 2) {
        ctx_open = 0; ctx_sub = 0; return;
    }

    /* Submenu check first */
    if (ctx_sub && mx >= x + CTX_W && mx < x + CTX_W + CTX_SUB_W) {
        int si = (my - y) / CTX_ITEM_H;
        if (si >= 0 && si < 3) {
            ctx_open = 0; ctx_sub = 0;
            if (si == 0) naming_start("New Folder", create_folder_cb);
            else if (si == 1) naming_start("New File", create_file_cb);
            else naming_start("New Config", create_ini_cb);
        }
        return;
    }

    /* Arrow > click to open submenu */
    if (mx >= x + CTX_W - 14 && mx < x + CTX_W &&
        my >= y + CTX_ITEM_H && my < y + 2*CTX_ITEM_H && !ctx_sub) {
        ctx_sub = 1; return;
    }

    /* Main menu items */
    int idx = (my - y) / CTX_ITEM_H;
    if (idx == 0) { ctx_open = 0; ctx_sub = 0; customize_open(); }
    else if (idx == 1 && !ctx_sub) { ctx_sub = 1; }
    else if (idx == 1) { }
}

static void ctx_render(void)
{
    if (!ctx_open) return;
    int x = ctx_x, y = ctx_y;
    fb_fillrect(x, y, CTX_W, 2*CTX_ITEM_H + 2, 0xD4D0C8);
    fb_rect3d(x, y, CTX_W, 2*CTX_ITEM_H + 2, 0xFFFFFF, 0x808080);

    int items_y[2] = {y, y + CTX_ITEM_H};
    const char *labels[2] = {"Customization", "Create"};
    for (int i = 0; i < 2; i++) {
        fb_fillrect(x + 2, items_y[i] + 2, CTX_W - 4, CTX_ITEM_H - 4, ctx_sub && i==1 ? 0x000080 : 0xD4D0C8);
        fb_drawstr(x + 8, items_y[i] + 6, labels[i], ctx_sub && i==1 ? 0xFFFFFF : 0x000000,
                   ctx_sub && i==1 ? 0x000080 : 0xD4D0C8);
        if (i == 1) fb_drawstr(x + CTX_W - 14, items_y[i] + 6, ">", 0x000000, 
                               ctx_sub ? 0x000080 : 0xD4D0C8);
    }

    if (ctx_sub) {
        int sx = x + CTX_W, sy = y;
        fb_fillrect(sx, sy, CTX_SUB_W, 3*CTX_ITEM_H + 2, 0xD4D0C8);
        fb_rect3d(sx, sy, CTX_SUB_W, 3*CTX_ITEM_H + 2, 0xFFFFFF, 0x808080);
        const char *sub_l[3] = {"Folder", "Text File", "INI File"};
        for (int i = 0; i < 3; i++) {
            fb_fillrect(sx + 2, items_y[i] + 2, CTX_SUB_W - 4, CTX_ITEM_H - 4, 0xD4D0C8);
            fb_drawstr(sx + 8, items_y[i] + 6, sub_l[i], 0x000000, 0xD4D0C8);
        }
    }
}

/* ===== Desktop folder/file callbacks ===== */
static void create_folder_cb(const char *name)
{
    char nbuf[32];
    make_unique_name(nbuf, 32, name);
    int i = add_di(40 + (di_cnt % 4) * 70, 310 + (di_cnt / 4) * 70, nbuf, DI_FOLDER, 0);
    if (i >= 0) { strcpy(ditems[i].name, nbuf); }
}

static void create_file_cb(const char *name)
{
    char nbuf[32];
    make_unique_name(nbuf, 32, name);
    int i = add_di(40 + (di_cnt % 4) * 70, 310 + (di_cnt / 4) * 70, nbuf, DI_FILE, 0);
    if (i >= 0) strcpy(ditems[i].name, nbuf);
}

static void create_ini_cb(const char *name)
{
    char nbuf[32];
    make_unique_name(nbuf, 32, name);
    int i = add_di(40 + (di_cnt % 4) * 70, 310 + (di_cnt / 4) * 70, nbuf, DI_INI, 0);
    if (i >= 0) strcpy(ditems[i].name, nbuf);
}

static void ictx_rename_cb(const char *name)
{
    if (ictx_rename_di >= 0 && ictx_rename_di < di_cnt) {
        int i;
        for (i = 0; name[i] && i < 31; i++) ditems[ictx_rename_di].name[i] = name[i];
        ditems[ictx_rename_di].name[i] = 0;
    }
    ictx_rename_di = -1;
}

static void ictx_click(int mx, int my)
{
    if (!ictx_open) return;
    int x = ictx_x, y = ictx_y;
    int h = ICTX_ITEMS * ICTX_ITEM_H + 2;
    if (mx < x || mx >= x + ICTX_W || my < y || my >= y + h) {
        ictx_open = 0; ictx_di = -1; ictx_rename_di = -1; return;
    }
    int n_items = (ditems[ictx_di].type >= DI_FILE) ? 3 : 2;
    int idx = (my - y) / ICTX_ITEM_H;
    if (idx >= n_items) { ictx_open = 0; ictx_di = -1; ictx_rename_di = -1; return; }
    int di = ictx_di;
    ictx_open = 0; ictx_di = -1;
    if (idx == 0) {
        ictx_rename_di = di;
        naming_start(ditems[di].name, ictx_rename_cb);
    } else if (idx == 1) {
        if (trash_cnt < MAX_TRASH) {
            trash_items[trash_cnt++] = ditems[di];
        }
        for (int j = di; j < di_cnt - 1; j++) ditems[j] = ditems[j + 1];
        di_cnt--;
        ictx_rename_di = -1;
    } else if (idx == 2 && ditems[di].type >= DI_FILE) {
        notepad_open(ditems[di].name, ditems[di].content, &ditems[di].content_len);
        ictx_rename_di = -1;
    }
}

static void ictx_render(void)
{
    if (!ictx_open) return;
    if (ictx_di < 0 || ictx_di >= di_cnt) { ictx_open = 0; return; }
    int x = ictx_x, y = ictx_y;
    int n_items = (ditems[ictx_di].type >= DI_FILE) ? 3 : 2;
    int h = n_items * ICTX_ITEM_H + 2;
    fb_fillrect(x, y, ICTX_W, h, 0xD4D0C8);
    fb_rect3d(x, y, ICTX_W, h, 0xFFFFFF, 0x808080);
    const char *labels[3] = {"Rename", "Delete", "Edit"};
    for (int i = 0; i < n_items; i++) {
        int iy = y + 2 + i * ICTX_ITEM_H;
        fb_fillrect(x + 2, iy, ICTX_W - 4, ICTX_ITEM_H - 4, 0xD4D0C8);
        fb_drawstr(x + 8, iy + 5, labels[i], 0x000000, 0xD4D0C8);
    }
}

/* ===== Customization ===== */
static wnd_t *cust_wnd = 0;
static uint32_t colors[] = {0x008080, 0x000080, 0x800000, 0x008000, 0x808000, 0x800080, 0x000000, 0x404040, 0x004040, 0x000000};
static int ncolors = 9;

static void cust_render(wnd_t *w)
{
    int x = w->x + 8, y = w->y + TITLE_H + 8;
    fb_drawstr(x, y, "Desktop Background", 0xFFFFFF, 0x1A1A2E); y += 20;
    fb_drawstr(x, y, "Color:", 0xCCCCCC, 0x1A1A2E); y += 16;
    for (int i = 0; i < ncolors; i++) {
        int cx = x + (i % 5) * 40, cy = y + (i / 5) * 34;
        fb_fillrect(cx, cy, 30, 24, colors[i]);
        fb_rect3d(cx, cy, 30, 24, 0xFFFFFF, 0x808080);
    }
    int color_end_y = y + ((ncolors + 4) / 5) * 34 + 8;
    y = color_end_y;
    fb_drawstr(x, y, "Wallpaper:", 0xCCCCCC, 0x1A1A2E); y += 16;
    for (int i = 0; i < WP_COUNT; i++) {
        uint32_t bg = (desk_wallpaper == i) ? 0x000080 : 0x1A1A2E;
        uint32_t fg = (desk_wallpaper == i) ? 0xFFFFFF : 0xCCCCCC;
        fb_fillrect(x + 2, y, w->w - 20, 18, bg);
        fb_drawstr(x + 6, y + 4, wp_names[i], fg, bg);
        y += 20;
    }
}

static void cust_click(wnd_t *w, int mx, int my)
{
    int x = w->x + 8, y = w->y + TITLE_H + 44;
    for (int i = 0; i < ncolors; i++) {
        int cx = x + (i % 5) * 40, cy = y + (i / 5) * 34;
        if (mx >= cx && mx < cx + 30 && my >= cy && my < cy + 24) {
            desk_color = colors[i];
            desk_wallpaper = -1;
            return;
        }
    }
    y = y + ((ncolors + 4) / 5) * 34 + 28;
    for (int i = 0; i < WP_COUNT; i++) {
        if (mx >= x + 2 && mx < x + w->w - 18 && my >= y && my < y + 18) {
            desk_wallpaper = i;
            return;
        }
        y += 20;
    }
}

static void cust_on_close(wnd_t *w) { (void)w; cust_wnd = 0; }

int ctx_menu_is_open(void) { return ctx_open; }

void customize_open(void)
{
    if (cust_wnd) {
        if (cust_wnd->flags & WND_VISIBLE) { wm_raise(cust_wnd); return; }
        wm_restore(cust_wnd); return;
    }
    cust_wnd = wm_create(200, 100, 240, 280, "Customization");
    if (!cust_wnd) return;
    cust_wnd->render = cust_render;
    cust_wnd->click = cust_click;
    cust_wnd->on_close = cust_on_close;
}

/* ===== Trash window ===== */
static void trash_clear_confirm(void);
static void trash_render(wnd_t *w)
{
    int x = w->x + 8, y = w->y + TITLE_H + 8;
    fb_drawstr(x, y, "Recycle Bin", 0xFFFFFF, 0x1A1A2E); y += 20;
    if (trash_cnt == 0) {
        fb_drawstr(x + 4, y + 10, "The Recycle Bin is empty.", 0x888888, 0x1A1A2E);
        return;
    }
    for (int i = 0; i < trash_cnt; i++) {
        int iy = y + i * 18;
        fb_fillrect(x + 2, iy, w->w - 20, 16, 0x1A1A2E);
        fb_drawstr(x + 6, iy + 3, trash_items[i].name, 0xCCCCCC, 0x1A1A2E);
    }
    /* Clear button at top-right of content */
    int bx = w->x + w->w - 64;
    fb_fillrect(bx, w->y + TITLE_H + 4, 56, 18, 0xC0C0C0);
    fb_rect3d(bx, w->y + TITLE_H + 4, 56, 18, 0xFFFFFF, 0x808080);
    fb_drawstr(bx + 6, w->y + TITLE_H + 7, "Clear", 0x000000, 0xC0C0C0);
}

static void trash_click(wnd_t *w, int mx, int my)
{
    (void)w;
    int bx = w->x + w->w - 64;
    if (mx >= bx && mx < bx + 56 &&
        my >= w->y + TITLE_H + 4 && my < w->y + TITLE_H + 22) {
        if (trash_cnt > 0) trash_clear_confirm();
        return;
    }
}

static void trash_on_close(wnd_t *w) { (void)w; trash_wnd = 0; }

static void trash_open(void)
{
    if (trash_wnd) {
        if (trash_wnd->flags & WND_VISIBLE) { wm_raise(trash_wnd); return; }
        wm_restore(trash_wnd); return;
    }
    trash_wnd = wm_create(200, 80, 360, 300, "Recycle Bin");
    if (!trash_wnd) return;
    trash_wnd->render = trash_render;
    trash_wnd->click = trash_click;
    trash_wnd->on_close = trash_on_close;
}

/* ===== Trash clear confirmation ===== */
static void trash_confirm_render(wnd_t *w)
{
    int x = w->x + 8, y = w->y + TITLE_H + 10;
    fb_drawstr(x, y, "If you delete these files,", 0xFFFFFF, 0x1A1A2E); y += 14;
    fb_drawstr(x, y, "they cannot be restored.", 0xFFFFFF, 0x1A1A2E); y += 24;
    int bx = x + 20;
    fb_fillrect(bx, y, 50, 20, 0xC0C0C0);
    fb_rect3d(bx, y, 50, 20, 0xFFFFFF, 0x808080);
    fb_drawstr(bx + 8, y + 4, "Yes", 0x000000, 0xC0C0C0);
    fb_fillrect(bx + 60, y, 50, 20, 0xC0C0C0);
    fb_rect3d(bx + 60, y, 50, 20, 0xFFFFFF, 0x808080);
    fb_drawstr(bx + 68, y + 4, "No", 0x000000, 0xC0C0C0);
}

static void trash_confirm_click(wnd_t *w, int mx, int my)
{
    int x = w->x + 28, y = w->y + TITLE_H + 48;
    if (my >= y && my < y + 20) {
        if (mx >= x && mx < x + 50) {
            trash_cnt = 0;
            if (trash_confirm_wnd) {
                wm_destroy(trash_confirm_wnd);
                trash_confirm_wnd = 0;
            }
            return;
        }
        if (mx >= x + 60 && mx < x + 110) {
            if (trash_confirm_wnd) {
                wm_destroy(trash_confirm_wnd);
                trash_confirm_wnd = 0;
            }
            return;
        }
    }
}

static void trash_confirm_on_close(wnd_t *w) { (void)w; trash_confirm_wnd = 0; }

static void trash_clear_confirm(void)
{
    if (trash_confirm_wnd) return;
    trash_confirm_wnd = wm_create(250, 200, 300, 130, "Empty Recycle Bin");
    if (!trash_confirm_wnd) return;
    trash_confirm_wnd->render = trash_confirm_render;
    trash_confirm_wnd->click = trash_confirm_click;
    trash_confirm_wnd->on_close = trash_confirm_on_close;
    wm_raise(trash_confirm_wnd);
}

/* ===== Icon drawing ===== */
static void draw_mc_icon(int x, int y, int sz)
{
    fb_fillrect(x + 4, y + 4, sz - 8, sz - 8, 0x0D111A);
    fb_rect3d(x + 4, y + 4, sz - 8, sz - 8, 0xFFFFFF, 0x404040);
    fb_drawstr(x + 8, y + 14, "PC", 0x4488FF, 0x0D111A);
    fb_drawstr(x + 9, y + 26, "C:", 0x4488FF, 0x0D111A);
}

static void draw_about_icon(int x, int y, int sz)
{
    fb_fillrect(x + 6, y + 8, sz - 12, sz - 16, 0xFFFFF0);
    fb_rect3d(x + 6, y + 8, sz - 12, sz - 16, 0xFFFFFF, 0x808080);
    int lx = x + 12, ly = y + 14;
    fb_fillrect(lx, ly, 20, 2, 0xBBBBBB);
    fb_fillrect(lx, ly + 6, 15, 2, 0xBBBBBB);
    fb_fillrect(lx, ly + 12, 18, 2, 0xBBBBBB);
}

static void draw_trash_icon(int x, int y, int sz)
{
    if (trash_cnt == 0) {
        /* Empty bin */
        fb_fillrect(x + 12, y + 6, sz - 24, sz - 18, 0x0D111A);
        fb_rect3d(x + 12, y + 6, sz - 24, sz - 18, 0x808080, 0x404040);
        fb_drawstr(x + 14, y + 14, "T", 0x888888, 0x0D111A);
        fb_fillrect(x + 8, y + sz - 14, sz - 16, 6, 0x0D111A);
        fb_rect3d(x + 8, y + sz - 14, sz - 16, 6, 0x808080, 0x404040);
    } else {
        /* Full bin - crumpled papers */
        fb_fillrect(x + 8, y + 4, sz - 16, sz - 10, 0x0D111A);
        fb_rect3d(x + 8, y + 4, sz - 16, sz - 10, 0x808080, 0x404040);
        fb_drawstr(x + 10, y + 10, "T", 0x888888, 0x0D111A);
        fb_fillrect(x + 12, y + 8, 10, 10, 0xEEEEEE);
        fb_fillrect(x + 24, y + 14, 8, 8, 0xDDDDDD);
        fb_fillrect(x + 14, y + 22, 12, 8, 0xCCCCCC);
        fb_fillrect(x + 6, y + sz - 14, sz - 12, 6, 0x0D111A);
        fb_rect3d(x + 6, y + sz - 14, sz - 12, 6, 0x808080, 0x404040);
    }
}

/* ===== Init ===== */
static void launch_tga_demo(void)
{
    tga_viewer_demo();
}

void desktop_init(void)
{
    add_di(40, 40, "My Computer", DI_APP, explorer_open);
    add_di(40, 130, "About", DI_APP, launch_about);
    add_di(40, 220, "Trash", DI_APP, trash_open);
    add_di(110, 130, "TGA Demo", DI_APP, launch_tga_demo);
}

/* ===== Main render ===== */
void desktop_render(void)
{
    if (desk_wallpaper >= 0 && desk_wallpaper < WP_COUNT) {
        const uint32_t *img = wp_data[desk_wallpaper];
        uint32_t *buf = fb_getptr();
        for (int y = 0; y < fb_h - TH; y++) {
            const uint32_t *src = img + y * fb_w;
            uint32_t *dst = buf + y * fb_w;
            int n = fb_w;
            __asm__ volatile("rep movsl\n" : "+S"(src), "+D"(dst), "+c"(n) : : "memory");
        }
    } else {
        fb_fillrect(0, 0, fb_w, fb_h - TH, desk_color);
    }

    for (int i = 0; i < di_cnt; i++) {
        ditem_t *d = &ditems[i];
        int sz = 48;
        if (d->type == DI_APP) {
            fb_fillrect(d->x + 3, d->y + 3, sz, sz, 0x00000033);
            fb_rect3d(d->x, d->y, sz, sz, 0xFFFFFF, 0x004040);
            if (strcmp(d->name, "My Computer") == 0) draw_mc_icon(d->x, d->y, sz);
            else if (strcmp(d->name, "Trash") == 0) draw_trash_icon(d->x, d->y, sz);
            else if (strcmp(d->name, "TGA Demo") == 0) {
                fb_fillrect(d->x + 8, d->y + 6, sz - 16, sz - 12, 0x1A1A2E);
                fb_rect3d(d->x + 8, d->y + 6, sz - 16, sz - 12, 0x80FF80, 0x004000);
                fb_drawstr(d->x + 14, d->y + 18, "T", 0x80FF80, 0x1A1A2E);
                fb_drawstr(d->x + 13, d->y + 28, "G", 0x80FF80, 0x1A1A2E);
                fb_drawstr(d->x + 12, d->y + 38, "A", 0x80FF80, 0x1A1A2E);
            }
            else draw_about_icon(d->x, d->y, sz);
        } else if (d->type == DI_FOLDER) {
            fb_fillrect(d->x + 6, d->y + 6, sz - 12, sz - 12, 0x0D111A);
            fb_rect3d(d->x + 6, d->y + 6, sz - 12, sz - 12, 0xFFFF80, 0x808000);
            fb_drawstr(d->x + 14, d->y + 18, "F", 0xFFFF00, 0x0D111A);
        } else if (d->type == DI_FILE) {
            fb_fillrect(d->x + 10, d->y + 6, sz - 20, sz - 12, 0xEEEEEE);
            fb_rect3d(d->x + 10, d->y + 6, sz - 20, sz - 12, 0xFFFFFF, 0x808080);
            fb_drawstr(d->x + 14, d->y + 18, "T", 0x4488FF, 0xEEEEEE);
        } else if (d->type == DI_INI) {
            fb_fillrect(d->x + 10, d->y + 8, sz - 20, sz - 16, 0xE0E0C0);
            fb_rect3d(d->x + 10, d->y + 8, sz - 20, sz - 16, 0xFFFFFF, 0x808080);
            fb_drawstr(d->x + 13, d->y + 14, "~", 0x808080, 0xE0E0C0);
            fb_fillrect(d->x + 14, d->y + 22, 6, 2, 0x808080);
            fb_fillrect(d->x + 14, d->y + 28, 6, 2, 0x808080);
        }
        int lblen = strlen(d->name) * 9;
        int lx = d->x + (sz - lblen) / 2;
        if (lx < 0) lx = 0;
        fb_drawstr(lx, d->y + sz + 3, d->name, 0xFFFFFF, desk_color);
    }

}

void desktop_ovl_render(void)
{
    /* Start menu */
    if (start_open) {
        int sy = fb_h - TH - SM_H, sx = 2;
        fb_fillrect(sx, sy, SM_W, SM_H, 0xD4D0C8);
        fb_rect3d(sx, sy, SM_W, SM_H, 0xFFFFFF, 0x808080);
        fb_fillrect(sx + 2, sy + 2, SM_ICON_W + 2, SM_H - 4, 0x000080);
        fb_rect3d(sx + 2, sy + 2, SM_ICON_W + 2, SM_H - 4, 0x000040, 0x6666CC);
        fb_fillrect(sx + SM_ICON_W + 6, sy + 2, SM_W - SM_ICON_W - 10, 1, 0x808080);
        fb_fillrect(sx + SM_ICON_W + 6, sy + 3, SM_W - SM_ICON_W - 10, 1, 0xFFFFFF);
        int sep_y = sy + SM_H - 40;
        fb_fillrect(sx + SM_ICON_W + 6, sep_y, SM_W - SM_ICON_W - 10, 1, 0x808080);
        fb_fillrect(sx + SM_ICON_W + 6, sep_y + 1, SM_W - SM_ICON_W - 10, 1, 0xFFFFFF);
        for (int i = 0; i < SM_MENU_ITEMS; i++) {
            if (!sm_items[i].label) continue;
            int iy = sy + sm_item_y(i);
            if (sm_items[i].draw_icon) {
                sm_items[i].draw_icon(sx + 5, iy + 5);
                fb_drawstr(sx + SM_ICON_W + 12, iy + 7, sm_items[i].label, 0x000000, 0xD4D0C8);
            }
        }
    }

    /* Run dialog */
    if (run_open) {
        int sy = fb_h - TH - RUN_H, sx = 2;
        fb_fillrect(sx, sy, RUN_W, RUN_H, 0xD4D0C8);
        fb_rect3d(sx, sy, RUN_W, RUN_H, 0xFFFFFF, 0x808080);
        fb_fillrect(sx + 2, sy + 2, RUN_W - 4, 20, 0x000080);
        fb_rect3d(sx + 2, sy + 2, RUN_W - 4, 20, 0x6666CC, 0x000040);
        fb_drawstr(sx + 6, sy + 6, "Run", 0xFFFFFF, 0x000080);
        fb_drawstr(sx + 8, sy + 32, "Open:", 0x000000, 0xD4D0C8);
        fb_fillrect(sx + 50, sy + 30, RUN_W - 70, 18, 0xFFFFFF);
        fb_rect3d(sx + 50, sy + 30, RUN_W - 70, 18, 0x808080, 0xFFFFFF);
        fb_drawstr(sx + 53, sy + 32, run_buf, 0x000000, 0xFFFFFF);
        int cx = sx + 53 + run_len * 9;
        if (cx < sx + RUN_W - 25) fb_fillrect(cx, sy + 31, 1, 16, 0x000000);
        int bx = sx + RUN_W - 66;
        fb_fillrect(bx, sy + RUN_H - 28, 60, 20, 0xC0C0C0);
        fb_rect3d(bx, sy + RUN_H - 28, 60, 20, 0xFFFFFF, 0x808080);
        fb_drawstr(bx + 6, sy + RUN_H - 24, "Execute", 0x000000, 0xC0C0C0);
    }

    /* Context menu */
    ctx_render();

    /* Icon context menu */
    ictx_render();

    /* Naming dialog */
    naming_render();
}

/* ===== Icon drag ===== */
void desktop_drag_potential(int mx, int my)
{
    if (ctx_open || naming_active) return;
    for (int i = 0; i < di_cnt; i++) {
        if (mx >= ditems[i].x && mx < ditems[i].x + GRID_ICON_W &&
            my >= ditems[i].y && my < ditems[i].y + GRID_ICON_H) {
            drag_pot = i;
            drag_start_x = mx;
            drag_start_y = my;
            return;
        }
    }
    drag_pot = -1;
}

void desktop_dragmove(int mx, int my, int btn)
{
    (void)btn;
    if (drag_pot >= 0) {
        int dx = mx - drag_start_x;
        int dy = my - drag_start_y;
        if (dx*dx + dy*dy > DRAG_THRESH * DRAG_THRESH) {
            drag_di = drag_pot;
            drag_off_x = drag_start_x - ditems[drag_pot].x;
            drag_off_y = drag_start_y - ditems[drag_pot].y;
            drag_pot = -1;
        }
        return;
    }
    if (drag_di >= 0) {
        ditems[drag_di].x = mx - drag_off_x;
        ditems[drag_di].y = my - drag_off_y;
    }
}

void desktop_drag_end(void)
{
    if (drag_di >= 0) {
        grid_snap(&ditems[drag_di].x, &ditems[drag_di].y);
        drag_di = -1;
    }
    drag_pot = -1;
}

int ictx_menu_is_open(void) { return ictx_open; }

/* ===== Clicks ===== */
void desktop_click(int mx, int my)
{
    if (ictx_open) ictx_click(mx, my);
    if (ctx_open) ctx_click(mx, my);
    if (naming_active) naming_click(mx, my);
}

static void folder_empty_render(wnd_t *w)
{
    fb_drawstr(w->x + 10, w->y + TITLE_H + 14, "This folder is empty", 0xCCCCCC, 0x1A1A2E);
}

void desktop_dclick(int mx, int my)
{
    for (int i = 0; i < di_cnt; i++) {
        ditem_t *d = &ditems[i];
        if (mx >= d->x && mx < d->x + 48 && my >= d->y && my < d->y + 62) {
            if (d->type == DI_APP && d->click) d->click();
            else if (d->type >= DI_FILE) {
                notepad_open(d->name, d->content, &d->content_len);
            }
            else if (d->type == DI_FOLDER) {
                wnd_t *ew = wm_create(200 + i*10, 150 + i*10, 240, 100, d->name);
                if (ew) { ew->render = folder_empty_render; ew->key = 0; }
            }
            return;
        }
    }
}

/* ===== Start button logo ===== */
#include "start_logo.h"
static void draw_start_logo(int x, int y)
{
    for (int row = 0; row < LOGO_H; row++)
        for (int col = 0; col < LOGO_W; col++) {
            unsigned int c = logo_data[row][col];
            if (c >> 24)
                fb_putpixel(x + col, y + row, c & 0xFFFFFF);
        }
}

/* ===== Taskbar ===== */
void taskbar_render(void)
{
    int th = TH, ty = fb_h - th;
    fb_fillrect(0, ty, fb_w, th, 0xD4D0C8);
    fb_rect3d(0, ty, fb_w, th, 0xFFFFFF, 0x808080);
    int sb_w = 74, sb_x = 2;
    uint32_t sb_c = 0xD4D0C8;
    fb_fillrect(sb_x, ty + 2, sb_w, th - 4, sb_c);
    fb_rect3d(sb_x, ty + 2, sb_w, th - 4, start_open ? 0x808080 : 0xFFFFFF, start_open ? 0xFFFFFF : 0x808080);
    draw_start_logo(sb_x + 4, ty + 7);
    fb_drawstr(sb_x + 22, ty + 11, "Start", 0x000000, sb_c);
    int bx = sb_x + sb_w + 4;
    for (int i = 0; i < MAX_WNDS; i++) {
        wnd_t *w = &wnd_pool[i];
        if (w->flags & WND_FREE) continue;
        if (!(w->flags & WND_VISIBLE) && !(w->flags & WND_CLOSE)) continue;
        uint32_t bg = (w == wnd_active && (w->flags & WND_VISIBLE)) ? 0xC0B8A8 : 0xD4D0C8;
        if (!(w->flags & WND_VISIBLE) && (w->flags & WND_CLOSE)) bg = 0xE0DCD4;
        int btn_w = 120;
        fb_fillrect(bx, ty + 2, btn_w, th - 4, bg);
        fb_rect3d(bx, ty + 2, btn_w, th - 4, 0xFFFFFF, 0x808080);
        int offset = (!(w->flags & WND_VISIBLE)) ? 2 : 0;
        fb_drawstr(bx + 4 + offset, ty + 11 + offset, w->title, 0x000000, bg);
        bx += btn_w + 2;
    }
    int hh = 0, mm = 0, ss = 0;
    rtc_read_time(&hh, &mm, &ss);
    char tb[16];
    int ti = 0;
    if (hh < 10) tb[ti++] = '0';
    if (hh >= 10) { tb[ti++] = '0' + hh/10; tb[ti++] = '0' + hh%10; }
    else tb[ti++] = '0' + hh;
    tb[ti++] = ':';
    if (mm < 10) tb[ti++] = '0';
    tb[ti++] = '0' + mm/10; tb[ti++] = '0' + mm%10;
    tb[ti] = 0;
    fb_drawstr(fb_w - strlen(tb)*9 - 6, ty + 11, tb, 0x000000, 0xD4D0C8);
}

void taskbar_click(int mx, int my)
{
    if (my < fb_h - TH) return;
    int sb_w = 74, sb_x = 2;
    if (mx >= sb_x && mx < sb_x + sb_w) { start_toggle(); return; }
    start_open = 0;
    int bx = sb_x + sb_w + 4;
    for (int i = 0; i < MAX_WNDS; i++) {
        wnd_t *w = &wnd_pool[i];
        if (w->flags & WND_FREE) continue;
        if (!(w->flags & WND_VISIBLE) && !(w->flags & WND_CLOSE)) continue;
        int btn_w = 120;
        if (mx >= bx && mx < bx + btn_w) {
            if (w->flags & WND_VISIBLE) wm_raise(w);
            else wm_restore(w);
            return;
        }
        bx += btn_w + 2;
    }
}
