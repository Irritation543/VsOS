#include "string.h"

int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}

int strlen(const char *s)
{
    int n = 0;
    while (*s++) n++;
    return n;
}

char *strcpy(char *d, const char *s)
{
    char *r = d;
    while (*s) *d++ = *s++;
    *d = 0;
    return r;
}

int atoi(const char *s)
{
    int r = 0, sg = 1;
    while (*s == ' ') s++;
    if (*s == '-') { sg = -1; s++; }
    else if (*s == '+') s++;
    while (*s >= '0' && *s <= '9')
        r = r * 10 + (*s++ - '0');
    return r * sg;
}
