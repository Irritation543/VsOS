#ifndef KERNEL_H
#define KERNEL_H

void kernel_main(unsigned int magic, void *mb_info);

#endif
