#ifndef SOUND_H
#define SOUND_H

#include <stdint.h>

void beep(int freq, int duration_ms);

/* AC97 / WAV / PCM */
int  ac97_init(void);
int  ac97_play_wav(const unsigned char *wav_data, int wav_len);
int  ac97_play_pcm(const unsigned char *data, int size);
int  ac97_play_startup(void);
int  ac97_play_shutdown(void);
int  ac97_play_critical(void);
int  ac97_play_notification(void);
int  ac97_is_initialized(void);
int  ac97_diag(void);
void ac97_stop(void);
void ac97_get_info(char *buf, int max_len);
uint32_t ac97_get_bdl_addr(void);
uint32_t ac97_get_buf_addr(void);
int      ac97_get_bdl_aligned(void);
int      ac97_get_buf_aligned(void);

/* Exposed for diagnostics */
extern uint16_t nambar;
extern uint16_t nabmbar;

#endif
