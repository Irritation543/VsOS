#include "tga.h"
#include "wm.h"
#include "fb.h"
#include "string.h"
#include <stdint.h>

/* ===== TGA Decoder ===== */
/* TGA header (18 bytes) */
typedef struct {
    uint8_t  id_len;
    uint8_t  cmap_type;
    uint8_t  image_type;
    uint16_t cmap_start;
    uint16_t cmap_len;
    uint8_t  cmap_bpp;
    uint16_t x_origin;
    uint16_t y_origin;
    uint16_t width;
    uint16_t height;
    uint8_t  bpp;
    uint8_t  descriptor;
} __attribute__((packed)) tga_header_t;

int tga_decode(const unsigned char *data, int data_len,
               uint32_t *pixels, int max_pixels,
               int *out_w, int *out_h, int *out_bpp)
{
    if (data_len < 18) return -1;

    const tga_header_t *hdr = (const tga_header_t *)data;
    int w = hdr->width;
    int h = hdr->height;
    int bpp = hdr->bpp;
    int img_type = hdr->image_type;

    if (w <= 0 || h <= 0) return -1;
    if (bpp != 24 && bpp != 32) return -1;
    if (img_type != 2 && img_type != 10) return -1;
    if (w * h > max_pixels) return -1;

    int topdown = (hdr->descriptor & 0x20) != 0;
    int pix_bytes = bpp / 8;

    /* Skip header + ID field */
    const unsigned char *src = data + 18 + hdr->id_len;
    int src_remain = data_len - (18 + hdr->id_len);

    for (int y = 0; y < h; y++) {
        int dy = topdown ? y : (h - 1 - y);
        for (int x = 0; x < w; x++) {
            uint32_t r, g, b, a = 0xFF;

            if (img_type == 2) {
                /* Uncompressed */
                if (src_remain < pix_bytes) return -1;
                b = src[0];
                g = src[1];
                r = src[2];
                if (bpp == 32) a = src[3];
                src += pix_bytes;
                src_remain -= pix_bytes;
            } else if (img_type == 10) {
                /* RLE: read pixel-by-pixel with run-length decoding */
                /* We'll handle RLE by pre-decoding a row at a time below */
            }

            pixels[dy * w + x] = (a << 24) | (r << 16) | (g << 8) | b;
        }
    }

    if (img_type == 10) {
        /* RLE decoding: redo by processing run-length packets */
        src = data + 18 + hdr->id_len;
        src_remain = data_len - (18 + hdr->id_len);
        int total_pixels = w * h;
        int written = 0;
        int row = 0;
        int col = 0;

        while (written < total_pixels && src_remain > 0) {
            if (src_remain < 1) return -1;
            uint8_t packet = *src++; src_remain--;
            int count = (packet & 0x7F) + 1;
            int rle = (packet & 0x80) != 0;

            if (rle) {
                if (src_remain < pix_bytes) return -1;
                uint32_t b = src[0], g = src[1], r = src[2], a = (bpp == 32) ? src[3] : 0xFF;
                src += pix_bytes; src_remain -= pix_bytes;

                for (int i = 0; i < count && written < total_pixels; i++) {
                    int dy = topdown ? row : (h - 1 - row);
                    pixels[dy * w + col] = (a << 24) | (r << 16) | (g << 8) | b;
                    col++;
                    if (col >= w) { col = 0; row++; }
                    written++;
                }
            } else {
                for (int i = 0; i < count && written < total_pixels; i++) {
                    if (src_remain < pix_bytes) return -1;
                    uint32_t b = src[0], g = src[1], r = src[2], a = (bpp == 32) ? src[3] : 0xFF;
                    src += pix_bytes; src_remain -= pix_bytes;
                    int dy = topdown ? row : (h - 1 - row);
                    pixels[dy * w + col] = (a << 24) | (r << 16) | (g << 8) | b;
                    col++;
                    if (col >= w) { col = 0; row++; }
                    written++;
                }
            }
        }
    }

    *out_w = w;
    *out_h = h;
    *out_bpp = bpp;
    return 0;
}

/* ===== TGA Viewer ===== */
#define TGA_MAX_W 800
#define TGA_MAX_H 600
static uint32_t tga_pixels[TGA_MAX_W * TGA_MAX_H];
static int tga_img_w, tga_img_h;
static const unsigned char *tga_src_data;
static int tga_src_len;
static const char *tga_title;

static wnd_t *tga_wnd = 0;

static void tga_render(wnd_t *w)
{
    int x = w->x + 4, y = w->y + TITLE_H + 4;
    int cw = w->w - 8, ch = w->h - TITLE_H - 8;

    fb_fillrect(x, y, cw, ch, 0x1A1A2E);

    /* Draw pixels, clipped to window */
    int draw_w = (tga_img_w < cw) ? tga_img_w : cw;
    int draw_h = (tga_img_h < ch) ? tga_img_h : ch;

    uint32_t *buf = fb_getptr();
    for (int row = 0; row < draw_h; row++) {
        uint32_t *src_line = tga_pixels + row * tga_img_w;
        uint32_t *dst_line = buf + (y + row) * fb_w + x;
        for (int col = 0; col < draw_w; col++) {
            dst_line[col] = src_line[col];
        }
    }

    if (tga_img_w > cw || tga_img_h > ch) {
        fb_drawstr(w->x + 6, w->y + TITLE_H + 6, "[Clipped]", 0xFF6666, 0x1A1A2E);
    }
}

static void tga_on_close(wnd_t *w)
{
    (void)w;
    tga_wnd = 0;
}

void tga_viewer_open(const unsigned char *tga_data, int data_len, const char *title)
{
    if (tga_wnd) {
        if (tga_wnd->flags & WND_VISIBLE) { wm_raise(tga_wnd); return; }
        wm_restore(tga_wnd); return;
    }

    int w, h, bpp;
    if (tga_decode(tga_data, data_len, tga_pixels, TGA_MAX_W * TGA_MAX_H, &w, &h, &bpp) != 0)
        return;

    tga_img_w = w;
    tga_img_h = h;
    tga_src_data = tga_data;
    tga_src_len = data_len;
    tga_title = title;

    int win_w = w + 12;
    int win_h = h + TITLE_H + 12;
    if (win_w > 800) win_w = 800;
    if (win_h > 600) win_h = 600;

    tga_wnd = wm_create(50, 50, win_w, win_h, title);
    if (!tga_wnd) return;
    tga_wnd->render = tga_render;
    tga_wnd->key = 0;
    tga_wnd->on_close = tga_on_close;
}

/* ===== Demo test card ===== */
/* Generate a test pattern TGA in memory */
#define DEMO_TGA_W 320
#define DEMO_TGA_H 240
static unsigned char demo_tga_data[18 + DEMO_TGA_W * DEMO_TGA_H * 3];

static void build_demo_tga(void)
{
    tga_header_t *hdr = (tga_header_t *)demo_tga_data;
    hdr->id_len = 0;
    hdr->cmap_type = 0;
    hdr->image_type = 2;  /* uncompressed true-color */
    hdr->cmap_start = 0;
    hdr->cmap_len = 0;
    hdr->cmap_bpp = 0;
    hdr->x_origin = 0;
    hdr->y_origin = 0;
    hdr->width = DEMO_TGA_W;
    hdr->height = DEMO_TGA_H;
    hdr->bpp = 24;
    hdr->descriptor = 0x20;  /* top-down */

    unsigned char *pixels = demo_tga_data + 18;
    for (int y = 0; y < DEMO_TGA_H; y++) {
        for (int x = 0; x < DEMO_TGA_W; x++) {
            int idx = (y * DEMO_TGA_W + x) * 3;
            if (x < DEMO_TGA_W/3) {
                if (y % 20 < 10 && x % 20 < 10) {
                    pixels[idx] = 0xFF; pixels[idx+1] = 0; pixels[idx+2] = 0;
                } else {
                    pixels[idx] = 0x80; pixels[idx+1] = 0; pixels[idx+2] = 0x80;
                }
            } else if (x < 2*DEMO_TGA_W/3) {
                if (y % 20 < 10 && x % 20 < 10) {
                    pixels[idx] = 0; pixels[idx+1] = 0xFF; pixels[idx+2] = 0;
                } else {
                    pixels[idx] = 0; pixels[idx+1] = 0x80; pixels[idx+2] = 0x80;
                }
            } else {
                if (y % 20 < 10 && x % 20 < 10) {
                    pixels[idx] = 0; pixels[idx+1] = 0; pixels[idx+2] = 0xFF;
                } else {
                    pixels[idx] = 0x80; pixels[idx+1] = 0x80; pixels[idx+2] = 0;
                }
            }
        }
    }
}

void tga_viewer_demo(void)
{
    build_demo_tga();
    tga_viewer_open(demo_tga_data, sizeof(demo_tga_data), "TGA Demo");
}
