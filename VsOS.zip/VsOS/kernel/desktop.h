#ifndef DESKTOP_H
#define DESKTOP_H

void desktop_init(void);
void desktop_render(void);
void desktop_ovl_render(void);
void desktop_click(int mx, int my);
void desktop_dclick(int mx, int my);
void desktop_rclick(int mx, int my);

void taskbar_render(void);
void taskbar_click(int mx, int my);

int  start_menu_open(void);
void start_menu_click(int mx, int my);

int  run_dialog_open(void);
void run_dialog_toggle(void);
void run_dialog_click(int mx, int my);
void run_dialog_key(char c);

int  naming_open(void);
void naming_start(const char *initial, void (*done)(const char *));
void naming_key(char c);
void naming_click(int mx, int my);
void naming_cancel(void);
void naming_render(void);

void customize_open(void);

int ctx_menu_is_open(void);
int ictx_menu_is_open(void);

void desktop_drag_potential(int mx, int my);
void desktop_dragmove(int mx, int my, int btn);
void desktop_drag_end(void);

#endif