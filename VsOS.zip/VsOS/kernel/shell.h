#ifndef SHELL_H
#define SHELL_H

void shell_init(void);
int  shell_process(void);

#endif
