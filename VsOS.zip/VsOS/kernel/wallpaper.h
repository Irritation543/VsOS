#ifndef WALLPAPER_H
#define WALLPAPER_H

#include <stdint.h>

#define WP_COUNT 2
extern const char *wp_names[WP_COUNT];
extern const uint32_t *wp_data[WP_COUNT];
extern const uint32_t wp_bliss[800*600];
extern const uint32_t wp_green_horizon[800*600];
#endif
