#include "terminal.h"
#include "wm.h"
#include "keyboard.h"
#include "fb.h"
#include "font.h"

#define CW 9
#define CH 10

static void scroll(term_t *t)
{
    int r;
    for (int c = 0; c < TCOLS; c++)
        t->scrollback[t->scb_wpos][c] = t->cells[0][c];
    t->scb_wpos = (t->scb_wpos + 1) % THISTORY;
    if (t->scb_count < THISTORY) t->scb_count++;

    for (r = 0; r < t->rows - 1; r++)
        for (int c = 0; c < t->cols; c++)
            t->cells[r][c] = t->cells[r + 1][c];
    for (int c = 0; c < t->cols; c++)
    {
        t->cells[t->rows - 1][c].c = ' ';
        t->cells[t->rows - 1][c].fg = t->fg;
        t->cells[t->rows - 1][c].bg = t->bg;
    }
    t->cy = t->rows - 1;
}

void term_init(term_t *t, wnd_t *w)
{
    t->wnd = w;
    t->fg = 0xCCCCCC;
    t->bg = 0x1A1A2E;
    t->cx = t->cy = 0;
    t->cols = 60;
    t->rows = 20;
    t->ihead = t->itail = 0;
    t->line_ready = 0;
    t->scb_wpos = 0;
    t->scb_count = 0;
    t->scroll_off = 0;
    term_clear(t);
}

void term_clear(term_t *t)
{
    int r = 0, c = 0;
    for (r = 0; r < TROWS; r++)
        for (c = 0; c < TCOLS; c++)
        {
            t->cells[r][c].c = ' ';
            t->cells[r][c].fg = t->fg;
            t->cells[r][c].bg = t->bg;
        }
    t->cx = t->cy = 0;
}

void term_setcolor(term_t *t, uint32_t fg, uint32_t bg)
{
    t->fg = fg;
    t->bg = bg;
}

void term_putchar(term_t *t, char c)
{
    t->scroll_off = 0;

    if (c == '\n')
    {
        t->cx = 0;
        t->cy++;
        if (t->cy >= t->rows) scroll(t);
        return;
    }
    if (c == '\b')
    {
        if (t->cx > 0) t->cx--;
        t->cells[t->cy][t->cx].c = ' ';
        t->cells[t->cy][t->cx].fg = t->fg;
        t->cells[t->cy][t->cx].bg = t->bg;
        return;
    }
    if (c == '\r') { t->cx = 0; return; }

    if (t->cx >= t->cols) { t->cx = 0; t->cy++; }
    if (t->cy >= t->rows) scroll(t);

    t->cells[t->cy][t->cx].c = c;
    t->cells[t->cy][t->cx].fg = t->fg;
    t->cells[t->cy][t->cx].bg = t->bg;
    t->cx++;
}

void term_write(term_t *t, const char *s)
{
    for (; *s; s++) term_putchar(t, *s);
}

static void put_u(unsigned int n, term_t *t)
{
    char buf[16];
    int i = 0;
    if (n == 0) { term_putchar(t, '0'); return; }
    while (n) { buf[i++] = "0123456789ABCDEF"[n % 10]; n /= 10; }
    while (i) term_putchar(t, buf[--i]);
}

void term_printf(term_t *t, const char *fmt, ...)
{
    __builtin_va_list ap;
    __builtin_va_start(ap, fmt);
    for (; *fmt; fmt++)
    {
        if (*fmt != '%') { term_putchar(t, *fmt); continue; }
        fmt++;
        switch (*fmt)
        {
            case 'd': put_u(__builtin_va_arg(ap, int), t); break;
            case 's': term_write(t, __builtin_va_arg(ap, const char *)); break;
            case 'c': term_putchar(t, __builtin_va_arg(ap, int)); break;
            case 'x':
            case 'X': {
                unsigned int v = __builtin_va_arg(ap, unsigned int);
                char buf[16]; int i = 0;
                if (v == 0) { term_putchar(t, '0'); break; }
                while (v) { buf[i++] = "0123456789ABCDEF"[v % 16]; v /= 16; }
                while (i) term_putchar(t, buf[--i]);
                break;
            }
            case '%': term_putchar(t, '%'); break;
            case 0: goto end;
        }
    }
    end:
    __builtin_va_end(ap);
}

static void ibuf_put(term_t *t, char c)
{
    int next = (t->ihead + 1) % (int)(sizeof(t->ibuf));
    if (next == t->itail) return;
    t->ibuf[t->ihead] = c;
    t->ihead = next;
}

static int ibuf_get(term_t *t, char *c)
{
    if (t->itail == t->ihead) return 0;
    *c = t->ibuf[t->itail];
    t->itail = (t->itail + 1) % (int)(sizeof(t->ibuf));
    return 1;
}

void term_key(term_t *t, char c)
{
    t->scroll_off = 0;

    if (c == '\n')
    {
        ibuf_put(t, '\n');
        t->line_ready = 1;
    }
    else if (c == '\b')
    {
        ibuf_put(t, '\b');
    }
    else
    {
        ibuf_put(t, c);
    }
    term_putchar(t, c);
}

int term_readline(term_t *t, char *buf, int max)
{
    if (!t->line_ready) return 0;
    int i = 0;
    char c;
    while (ibuf_get(t, &c) && i < max - 1)
    {
        if (c == '\n') { buf[i] = 0; t->line_ready = 0; return i; }
        if (c == '\b') { if (i > 0) i--; }
        else { buf[i++] = c; }
    }
    if (i > 0) { buf[i] = 0; t->line_ready = 0; return i; }
    t->line_ready = 0;
    return 0;
}

void term_render(wnd_t *w)
{
    term_t *t = (term_t *)w->data;
    if (!t) return;

    int cols = (w->w - 8) / CW;
    int rows = (w->h - TITLE_H - 8) / CH;
    if (cols < 8) cols = 8;
    if (rows < 3) rows = 3;
    if (cols > TCOLS) cols = TCOLS;
    if (rows > TROWS) rows = TROWS;
    t->cols = cols;
    t->rows = rows;

    int ox = w->x + 4;
    int oy = w->y + TITLE_H + 4;

    int sb_rows = t->scroll_off;
    if (sb_rows > t->scb_count) sb_rows = t->scb_count;

    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            tcell_t *src;
            if (r < sb_rows) {
                int idx = (t->scb_wpos - sb_rows + r) % THISTORY;
                if (idx < 0) idx += THISTORY;
                src = &t->scrollback[idx][c];
            } else {
                src = &t->cells[r - sb_rows][c];
            }

            int px = ox + c * CW;
            int py = oy + r * CH;
            fb_fillrect(px, py, CW, CH, src->bg);
            for (int rr = 0; rr < 8; rr++)
            {
                uint8_t bits = font8x8[(unsigned char)src->c][rr];
                for (int cc = 0; cc < 8; cc++)
                    if (bits & (1 << (7 - cc)))
                        fb_putpixel(px + cc, py + rr, src->fg);
            }
        }
    }

    if (t->scroll_off == 0 && t->cx < cols && t->cy < rows)
        fb_fillrect(ox + t->cx * CW, oy + t->cy * CH, CW, CH, t->fg);
}

void term_key_special(term_t *t, int code)
{
    if (code == KEY_PGUP) {
        t->scroll_off += t->rows - 1;
        if (t->scroll_off > t->scb_count + t->rows - 1)
            t->scroll_off = t->scb_count + t->rows - 1;
    } else if (code == KEY_PGDN) {
        t->scroll_off -= t->rows - 1;
        if (t->scroll_off < 0) t->scroll_off = 0;
    }
}

static void term_key_handler(wnd_t *w, char c)
{
    term_t *t = (term_t *)w->data;
    if (t) term_key(t, c);
}

static void term_key_special_handler(wnd_t *w, int code)
{
    term_t *t = (term_t *)w->data;
    if (t) term_key_special(t, code);
}

static void term_on_close(wnd_t *w)
{
    term_t *t = (term_t *)w->data;
    if (t) t->wnd = 0;
}

void terminal_launch(void)
{
    extern term_t main_term;
    if (main_term.wnd)
    {
        if (main_term.wnd->flags & WND_VISIBLE) return;
        wm_restore(main_term.wnd);
        return;
    }
    wnd_t *w = wm_create(30, 40, 60 * CW + 8, 20 * CH + TITLE_H + 8, "Terminal");
    if (!w) return;
    w->data = &main_term;
    w->render = term_render;
    w->key = term_key_handler;
    w->key_special = term_key_special_handler;
    w->on_close = term_on_close;
    term_init(&main_term, w);
}
