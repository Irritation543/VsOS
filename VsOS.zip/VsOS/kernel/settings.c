#include "settings.h"
#include "wm.h"
#include "fb.h"
#include "desktop.h"
#include "sound.h"
#include "rtc.h"
#include "string.h"
#include <stdint.h>

int mouse_speed = 100;
int font_scale = 100;
int master_volume = 100;
int notification_volume = 100;

static wnd_t *set_wnd = 0;
static int set_category = 0;
static int set_dropdown = -1;
static int set_dropdown_hover = -1;
static int set_drag_slider = -1;

#define CAT_W 120
#define CONTENT_X (CAT_W + 4)
#define LINE_H 28
#define SLIDER_W 120
#define SLIDER_H 10
#define HANDLE_W 10
#define HANDLE_H 14
#define BTN_H 20
#define DROPDOWN_H 18

static uint32_t bg = 0x1A1A2E;

static const char *res_options[] = {
    "640 x 480", "800 x 600  (Recommended)", "1024 x 768", "1280 x 720"
};
#define RES_COUNT 4

static const char *scale_options[] = { "70%", "80%", "90%", "100%  (Default)", "125%" };
static const int scale_values[] = { 70, 80, 90, 100, 125 };
#define SCALE_COUNT 5

extern void customize_open(void);

static int slider_x(wnd_t *w, int base_y)
{ (void)base_y; return w->x + CONTENT_X + 90; }
static int slider_y(wnd_t *w, int base_y)
{ (void)w; return base_y + (LINE_H - SLIDER_H) / 2; }

static int hx_from_val(int val, int min_v, int max_v, int sx)
{
    int r = max_v - min_v; return r > 0 ? sx + (val - min_v) * SLIDER_W / r : sx;
}
static int val_from_hx(int mx, int sx, int min_v, int max_v)
{
    int r = max_v - min_v;
    if (r <= 0) return min_v;
    if (mx < sx) return min_v;
    if (mx >= sx + SLIDER_W) return max_v;
    return min_v + (mx - sx) * r / SLIDER_W;
}

static void draw_slider(int sx, int sy, int val, int min_v, int max_v)
{
    fb_fillrect(sx, sy, SLIDER_W, SLIDER_H, 0x404040);
    int fw = (max_v > min_v) ? (val - min_v) * SLIDER_W / (max_v - min_v) : 0;
    if (fw > 0) fb_fillrect(sx, sy, fw, SLIDER_H, 0x4488FF);
    fb_rect3d(sx, sy, SLIDER_W, SLIDER_H, 0x808080, 0x000000);
    int hx = hx_from_val(val, min_v, max_v, sx);
    fb_fillrect(hx - HANDLE_W/2, sy - (HANDLE_H - SLIDER_H)/2, HANDLE_W, HANDLE_H, 0xCCCCCC);
    fb_rect3d(hx - HANDLE_W/2, sy - (HANDLE_H - SLIDER_H)/2, HANDLE_W, HANDLE_H, 0xFFFFFF, 0x808080);
}

static void draw_dd_btn(int bx, int by, int bw, const char *text, int open)
{
    fb_fillrect(bx, by, bw, BTN_H, 0xC0C0C0);
    fb_rect3d(bx, by, bw, BTN_H, open ? 0x808080 : 0xFFFFFF, open ? 0xFFFFFF : 0x808080);
    fb_drawstr(bx + 4, by + 4, text, 0x000000, 0xC0C0C0);
    int ax = bx + bw - 14;
    fb_fillrect(ax, by + 6, 8, 1, 0x000000);
    fb_fillrect(ax + 1, by + 8, 6, 1, 0x000000);
    fb_fillrect(ax + 2, by + 10, 4, 1, 0x000000);
    fb_fillrect(ax + 3, by + 12, 2, 1, 0x000000);
}

static void draw_dd_panel(int px, int py, int pw, const char **opts, int cnt, int sel, int hover)
{
    int ph = cnt * DROPDOWN_H + 2;
    fb_fillrect(px, py, pw, ph, 0xD4D0C8);
    fb_rect3d(px, py, pw, ph, 0xFFFFFF, 0x000000);
    for (int i = 0; i < cnt; i++) {
        int iy = py + 2 + i * DROPDOWN_H;
        uint32_t ibg = (i == hover) ? 0x000080 : 0xD4D0C8;
        uint32_t ifg = (i == hover) ? 0xFFFFFF : 0x000000;
        fb_fillrect(px + 2, iy, pw - 4, DROPDOWN_H, ibg);
        fb_drawstr(px + 6, iy + 4, opts[i], ifg, ibg);
        if (i == sel) fb_drawstr(px + pw - 16, iy + 4, "*", 0x4488FF, ibg);
    }
}

static void num_str(char *buf, int val)
{
    int i = 0;
    if (val >= 100) { buf[i++] = '0' + val/100; val %= 100; }
    buf[i++] = '0' + val/10; buf[i++] = '0' + val%10; buf[i] = 0;
}

/* ─── Render ────────────────────────────────────────────────── */
static void set_render(wnd_t *w)
{
    fb_fillrect(w->x + 4, w->y + TITLE_H + 4, w->w - 8, w->h - TITLE_H - 8, bg);

    /* Category buttons */
    const char *cats[] = {"Mouse", "Display", "Customize", "Sound"};
    for (int i = 0; i < 4; i++) {
        int cy = w->y + TITLE_H + 8 + i * 34;
        uint32_t cb = (i == set_category) ? 0x000080 : 0x2A2A3E;
        uint32_t cf = (i == set_category) ? 0xFFFFFF : 0xCCCCCC;
        fb_fillrect(w->x + 4, cy, CAT_W - 4, 28, cb);
        fb_drawstr(w->x + 10, cy + 8, cats[i], cf, cb);
    }

    int cx = w->x + CONTENT_X, y = w->y + TITLE_H + 8;
    char buf[8];

    if (set_category == 0) { /* Mouse */
        fb_drawstr(cx, y, "Mouse Sensitivity", 0xFFFFFF, bg); y += LINE_H;
        fb_drawstr(cx, y, "Speed:", 0xCCCCCC, bg);
        draw_slider(slider_x(w, y), slider_y(w, y), mouse_speed, 20, 200);
        num_str(buf, mouse_speed);
        fb_drawstr(slider_x(w, y) + SLIDER_W + 8, slider_y(w, y), buf, 0xFFFFFF, bg);
    }
    else if (set_category == 1) { /* Display */
        fb_drawstr(cx, y, "Display Settings", 0xFFFFFF, bg); y += LINE_H;
        fb_drawstr(cx, y, "Resolution:", 0xCCCCCC, bg);
        draw_dd_btn(cx + 90, y, 180, res_options[1], set_dropdown == 0);
        y += BTN_H + 8;
        fb_drawstr(cx, y, "Text Size:", 0xCCCCCC, bg);
        int si = 0; char sb[8];
        sb[si++] = '0' + font_scale/100 % 10; sb[si++] = '0' + font_scale/10 % 10;
        sb[si++] = '%'; sb[si] = 0;
        draw_dd_btn(cx + 90, y, 140, sb, set_dropdown == 1);
        y += BTN_H + 8;
        if (set_dropdown == 0)
            draw_dd_panel(cx + 90, y, 180, res_options, RES_COUNT, 1, set_dropdown_hover);
        else if (set_dropdown == 1)
            draw_dd_panel(cx + 90, y, 140, scale_options, SCALE_COUNT, 3, set_dropdown_hover);
        y += 10;
        fb_fillrect(cx, y, 300, 1, 0x404040); y += 10;
        fb_drawstr(cx, y, "Set Time", 0xFFFFFF, bg); y += LINE_H;
        int hh = 0, mm = 0, ss = 0;
        rtc_read_time(&hh, &mm, &ss);
        char ts[32]; int tii = 0;
        ts[tii++] = '0' + hh/10; ts[tii++] = '0' + hh%10;
        ts[tii++] = ':';
        ts[tii++] = '0' + mm/10; ts[tii++] = '0' + mm%10;
        ts[tii] = 0;
        fb_drawstr(cx, y, ts, 0xCCCCCC, bg);
        int bx = cx + 90;
        fb_fillrect(bx, y, 24, BTN_H, 0xC0C0C0);
        fb_rect3d(bx, y, 24, BTN_H, 0xFFFFFF, 0x808080);
        fb_drawstr(bx + 4, y + 4, "H-", 0x000000, 0xC0C0C0);
        bx += 28;
        fb_fillrect(bx, y, 24, BTN_H, 0xC0C0C0);
        fb_rect3d(bx, y, 24, BTN_H, 0xFFFFFF, 0x808080);
        fb_drawstr(bx + 4, y + 4, "H+", 0x000000, 0xC0C0C0);
        bx += 28;
        fb_fillrect(bx, y, 24, BTN_H, 0xC0C0C0);
        fb_rect3d(bx, y, 24, BTN_H, 0xFFFFFF, 0x808080);
        fb_drawstr(bx + 4, y + 4, "M-", 0x000000, 0xC0C0C0);
        bx += 28;
        fb_fillrect(bx, y, 24, BTN_H, 0xC0C0C0);
        fb_rect3d(bx, y, 24, BTN_H, 0xFFFFFF, 0x808080);
        fb_drawstr(bx + 4, y + 4, "M+", 0x000000, 0xC0C0C0);
    }
    else if (set_category == 2) { /* Customize */
        fb_drawstr(cx, y + 4, "Customize your desktop", 0xFFFFFF, bg);
        fb_drawstr(cx, y + 24, "Wallpaper, colors and more.", 0xCCCCCC, bg);
        int by = y + 48;
        fb_fillrect(cx, by, 120, 26, 0xC0C0C0);
        fb_rect3d(cx, by, 120, 26, 0xFFFFFF, 0x808080);
        fb_drawstr(cx + 12, by + 6, "Open", 0x000000, 0xC0C0C0);
    }
    else if (set_category == 3) { /* Sound */
        fb_drawstr(cx, y, "Sound Settings", 0xFFFFFF, bg); y += LINE_H;
        fb_drawstr(cx, y, "Master Volume:", 0xCCCCCC, bg);
        draw_slider(slider_x(w, y), slider_y(w, y), master_volume, 0, 100);
        num_str(buf, master_volume); fb_drawstr(slider_x(w, y) + SLIDER_W + 8, slider_y(w, y), buf, 0xFFFFFF, bg);
        y += LINE_H;
        fb_drawstr(cx, y, "Notification Volume:", 0xCCCCCC, bg);
        draw_slider(slider_x(w, y), slider_y(w, y), notification_volume, 0, 100);
        num_str(buf, notification_volume); fb_drawstr(slider_x(w, y) + SLIDER_W + 8, slider_y(w, y), buf, 0xFFFFFF, bg);
        y += LINE_H;
        fb_drawstr(cx, y, "Test sound:", 0xCCCCCC, bg);
        fb_fillrect(cx + 90, y, 60, BTN_H, 0xC0C0C0);
        fb_rect3d(cx + 90, y, 60, BTN_H, 0xFFFFFF, 0x808080);
        fb_drawstr(cx + 96, y + 4, "Play", 0x000000, 0xC0C0C0);
    }
}

/* ─── Clicks ─────────────────────────────────────────────────── */
static int inr(int mx, int my, int x, int y, int w, int h)
{ return mx >= x && mx < x + w && my >= y && my < y + h; }

static void set_click(wnd_t *w, int mx, int my)
{
    /* Close dropdown if clicking outside */
    if (set_dropdown >= 0) {
        if (set_category == 1) {
            int px = w->x + CONTENT_X + 90;
            int pw = (set_dropdown == 0) ? 180 : 140;
            int cnt = (set_dropdown == 0) ? RES_COUNT : SCALE_COUNT;
            int py = w->y + TITLE_H + 8 + LINE_H + BTN_H + 8 + BTN_H + 8;
            int ph = cnt * DROPDOWN_H + 2;
            if (inr(mx, my, px, py, pw, ph)) {
                int idx = (my - py - 2) / DROPDOWN_H;
                if (idx >= 0 && idx < cnt) {
                    if (set_dropdown == 0 && idx < RES_COUNT);
                    else if (set_dropdown == 1 && idx < SCALE_COUNT) font_scale = scale_values[idx];
                }
                set_dropdown = -1; set_dropdown_hover = -1; return;
            }
        }
        set_dropdown = -1; set_dropdown_hover = -1;
    }

    /* Category buttons */
    for (int i = 0; i < 4; i++)
        if (inr(mx, my, w->x + 4, w->y + TITLE_H + 8 + i * 34, CAT_W - 4, 28))
            { set_category = i; set_dropdown = -1; return; }

    int cx = w->x + CONTENT_X, y = w->y + TITLE_H + 8;

    if (set_category == 1) {
        int b1y = y + LINE_H;
        if (inr(mx, my, cx + 90, b1y, 180, BTN_H))
            { set_dropdown = (set_dropdown == 0) ? -1 : 0; return; }
        int b2y = y + LINE_H + BTN_H + 8;
        if (inr(mx, my, cx + 90, b2y, 140, BTN_H))
            { set_dropdown = (set_dropdown == 1) ? -1 : 1; return; }
        /* Time buttons */
        int ty = y + LINE_H + BTN_H + 8 + BTN_H + 8 + 10 + 10 + LINE_H;
        if (inr(mx, my, cx + 90, ty, 24, BTN_H)) { time_hour_offset--; return; }
        if (inr(mx, my, cx + 118, ty, 24, BTN_H)) { time_hour_offset++; return; }
        if (inr(mx, my, cx + 146, ty, 24, BTN_H)) { time_min_offset--; return; }
        if (inr(mx, my, cx + 174, ty, 24, BTN_H)) { time_min_offset++; return; }
    }

    if (set_category == 2) {
        if (inr(mx, my, cx, y + 48, 120, 26)) { customize_open(); return; }
    }

    if (set_category == 3) {
        if (inr(mx, my, cx + 90, y + LINE_H * 3, 60, BTN_H))
            { ac97_play_notification(); return; }
    }
}

/* ─── Mousedown: start slider drag ────────────────────────────── */
static void set_mousedown(wnd_t *w, int mx, int my)
{
    int y = w->y + TITLE_H + 8;
    if (set_category == 0) {
        int sx = slider_x(w, y), sy = slider_y(w, y);
        int hx = hx_from_val(mouse_speed, 20, 200, sx);
        if (inr(mx, my, hx - HANDLE_W/2, sy - (HANDLE_H - SLIDER_H)/2, HANDLE_W, HANDLE_H))
            { set_drag_slider = 0; return; }
    }
    if (set_category == 3) {
        int sx1 = slider_x(w, y + LINE_H), sy1 = slider_y(w, y + LINE_H);
        int hx1 = hx_from_val(master_volume, 0, 100, sx1);
        if (inr(mx, my, hx1 - HANDLE_W/2, sy1 - (HANDLE_H - SLIDER_H)/2, HANDLE_W, HANDLE_H))
            { set_drag_slider = 0; return; }
        int sx2 = slider_x(w, y + LINE_H*2), sy2 = slider_y(w, y + LINE_H*2);
        int hx2 = hx_from_val(notification_volume, 0, 100, sx2);
        if (inr(mx, my, hx2 - HANDLE_W/2, sy2 - (HANDLE_H - SLIDER_H)/2, HANDLE_W, HANDLE_H))
            { set_drag_slider = 1; return; }
    }
}

/* ─── Mousemove: drag slider, dropdown hover ──────────────────── */
static void set_mousemove(wnd_t *w, int mx, int my, int btn)
{
    /* Ignore if mouse outside window */
    if (mx < w->x || mx >= w->x + w->w || my < w->y || my >= w->y + w->h) {
        if (!btn) set_drag_slider = -1;
        return;
    }
    if (!btn) { set_drag_slider = -1; return; }
    if (set_drag_slider >= 0) {
        int y = w->y + TITLE_H + 8;
        int sx = slider_x(w, y);
        if (set_category == 0) {
            int v = val_from_hx(mx, sx, 20, 200);
            if (v < 20) v = 20;
            if (v > 200) v = 200;
            mouse_speed = v;
        } else if (set_category == 3) {
            int sx2 = slider_x(w, y + LINE_H * (1 + set_drag_slider));
            int v = val_from_hx(mx, sx2, 0, 100);
            if (v < 0) v = 0;
            if (v > 100) v = 100;
            if (set_drag_slider == 0) master_volume = v;
            else notification_volume = v;
        }
        return;
    }
    if (set_dropdown >= 0 && set_category == 1) {
        int px = w->x + CONTENT_X + 90;
        int cnt = (set_dropdown == 0) ? RES_COUNT : SCALE_COUNT;
        int py = w->y + TITLE_H + 8 + LINE_H + BTN_H + 8 + BTN_H + 8;
        int pw = (set_dropdown == 0) ? 180 : 140;
        int ph = cnt * DROPDOWN_H + 2;
        if (inr(mx, my, px, py, pw, ph)) {
            int idx = (my - py - 2) / DROPDOWN_H;
            set_dropdown_hover = (idx >= 0 && idx < cnt) ? idx : -1;
        } else set_dropdown_hover = -1;
    }
}

static void set_on_close(wnd_t *w) { (void)w; set_wnd = 0; }

void settings_open(void)
{
    if (set_wnd) {
        if (set_wnd->flags & WND_VISIBLE) { wm_raise(set_wnd); return; }
        wm_restore(set_wnd); return;
    }
    set_wnd = wm_create(80, 40, 480, 320, "Settings");
    if (!set_wnd) return;
    set_wnd->render = set_render;
    set_wnd->click = set_click;
    set_wnd->mousedown = set_mousedown;
    set_wnd->mousemove = set_mousemove;
    set_wnd->on_close = set_on_close;
    set_category = 0; set_dropdown = -1; set_dropdown_hover = -1; set_drag_slider = -1;
}
