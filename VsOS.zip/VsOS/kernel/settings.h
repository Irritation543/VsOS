#ifndef SETTINGS_H
#define SETTINGS_H

void settings_open(void);

/* Mouse sensitivity (100 = default) */
extern int mouse_speed;

/* Font scale (100 = default) */
extern int font_scale;

/* Volume levels (0-100) */
extern int master_volume;
extern int notification_volume;

#endif
