#ifndef WM_H
#define WM_H

#include <stdint.h>

#define TITLE_H 22
#define WND_CLOSE 0x01
#define WND_MINIMIZE 0x02
#define WND_VISIBLE 0x04
#define WND_FREE 0x10

typedef struct wnd {
    int x, y, w, h;
    char title[64];
    int z;
    int flags;
    int drag, dxx, dxy;
    int resize_edge;
    void (*render)(struct wnd *);
    void (*key)(struct wnd *, char);
    void (*key_special)(struct wnd *, int code);
    void (*click)(struct wnd *, int mx, int my);
    void (*mousemove)(struct wnd *, int mx, int my, int btn);
    void (*mousedown)(struct wnd *, int mx, int my);
    void (*on_close)(struct wnd *);
    void *data;
} wnd_t;

#define MAX_WNDS 16

void wm_init(void);
wnd_t *wm_create(int x, int y, int w, int h, const char *title);
void wm_render(void);
wnd_t *wm_at(int mx, int my);
void wm_raise(wnd_t *w);
void wm_click(int mx, int my, int btn);
void wm_mousemove(int mx, int my, int btn);
void wm_key(char c);
void wm_key_special(int code);
void wm_minimize(wnd_t *w);
void wm_restore(wnd_t *w);
void wm_destroy(wnd_t *w);

extern wnd_t *wnd_active;

#define CURSOR_NORMAL 0
#define CURSOR_H 1
#define CURSOR_V 2
#define CURSOR_HV 3
extern int cursor_type;

#endif
