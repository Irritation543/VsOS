#ifndef NOTEPAD_H
#define NOTEPAD_H

#include "wm.h"

wnd_t *notepad_open(const char *filename, char *content, int *content_len);

#endif