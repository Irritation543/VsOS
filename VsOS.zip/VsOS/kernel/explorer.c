#include "explorer.h"
#include "wm.h"
#include "fb.h"
#include "string.h"
#include "notepad.h"

#define MAX_ITEMS 64
#define MAX_PATH 128

typedef struct {
    const char *name;
    int is_dir;
    int parent;
    int first_child;
    int next_sibling;
} fs_t;

static fs_t fs[MAX_ITEMS];
static int fs_count = 0;

static int add_fs(const char *name, int is_dir, int parent)
{
    if (fs_count >= MAX_ITEMS) return -1;
    int i = fs_count++;
    fs[i].name = name;
    fs[i].is_dir = is_dir;
    fs[i].parent = parent;
    fs[i].first_child = -1;
    fs[i].next_sibling = -1;
    if (parent >= 0)
    {
        if (fs[parent].first_child < 0)
            fs[parent].first_child = i;
        else
        {
            int s = fs[parent].first_child;
            while (fs[s].next_sibling >= 0) s = fs[s].next_sibling;
            fs[s].next_sibling = i;
        }
    }
    return i;
}

static void init_filesystem(void)
{
    int root = add_fs("My Computer", 1, -1);
    int cdrive = add_fs("C:", 1, root);

    int pf = add_fs("Program Files", 1, cdrive);
    int vsos = add_fs("VsOS", 1, pf);
    add_fs("readme.txt", 0, vsos);
    add_fs("Common Files", 1, pf);

    int win = add_fs("Windows", 1, cdrive);
    int sys32 = add_fs("System32", 1, win);
    add_fs("kernel32.dll", 0, sys32);
    add_fs("user32.dll", 0, sys32);
    add_fs("cmd.exe", 0, sys32);
    int fonts = add_fs("Fonts", 1, win);
    add_fs("arial.ttf", 0, fonts);
    add_fs("times.ttf", 0, fonts);

    int users = add_fs("Users", 1, cdrive);
    int user = add_fs("User", 1, users);
    int desktop = add_fs("Desktop", 1, user);
    add_fs("readme.txt", 0, desktop);
    add_fs("notes.txt", 0, desktop);
    add_fs("Documents", 1, user);
    add_fs("Downloads", 1, user);

    int rsys32 = add_fs("System32", 1, cdrive);
    int config = add_fs("config", 1, rsys32);
    add_fs("system.reg", 0, config);
    int drivers = add_fs("drivers", 1, rsys32);
    add_fs("mouse.sys", 0, drivers);
    add_fs("keyboard.sys", 0, drivers);

    add_fs("Temp", 1, cdrive);
    add_fs("boot.ini", 0, cdrive);
    add_fs("autoexec.bat", 0, cdrive);
}

static wnd_t *exp_wnd = 0;
static int current_idx = 0;
static int scroll_offset = 0;

static void build_path(char *path, int max_len)
{
    int pi = 0;
    int ti = current_idx;
    char temp[16][32];
    int tc = 0;
    while (ti >= 0)
    {
        int len = strlen(fs[ti].name);
        int ci = 0;
        for (; ci < len && ci < 31; ci++) temp[tc][ci] = fs[ti].name[ci];
        temp[tc][ci] = 0;
        tc++;
        ti = fs[ti].parent;
    }
    for (int t = tc - 1; t >= 0; t--)
    {
        for (int c = 0; temp[t][c] && pi < max_len - 2; c++)
            path[pi++] = temp[t][c];
        if (t > 0) path[pi++] = '\\';
    }
    path[pi] = 0;
}

static void exp_render(wnd_t *w)
{
    int x = w->x + 4;
    int y = w->y + TITLE_H + 4;
    int cw = w->w - 8;
    int ch = w->h - TITLE_H - 8;

    /* Path bar */
    char path[MAX_PATH];
    build_path(path, MAX_PATH);
    fb_fillrect(x, y, cw, 16, 0xFFFFFF);
    fb_rect3d(x, y, cw, 16, 0x808080, 0xFFFFFF);
    fb_drawstr(x + 4, y + 3, path, 0x000000, 0xFFFFFF);

    /* Separator */
    y += 20;
    fb_fillrect(x, y, cw, 1, 0x808080);

    /* Items */
    y += 4;
    int item_h = 20;
    int items_shown = (ch - 30) / item_h;
    int item_count = 0;
    for (int s = fs[current_idx].first_child; s >= 0; s = fs[s].next_sibling)
        item_count++;

    if (scroll_offset + items_shown > item_count)
        scroll_offset = item_count - items_shown;
    if (scroll_offset < 0) scroll_offset = 0;

    int si = 0;
    int shown = 0;
    for (int s = fs[current_idx].first_child; s >= 0; s = fs[s].next_sibling)
    {
        if (si < scroll_offset) { si++; continue; }
        if (shown >= items_shown) break;

        int iy = y + shown * item_h;
        uint32_t bg = (shown % 2) ? 0x1A1A2E : 0x222244;
        fb_fillrect(x + 1, iy, cw - 2, item_h - 1, bg);

        if (fs[s].is_dir)
        {
            /* Folder icon */
            fb_fillrect(x + 3, iy + 3, 14, 11, 0xFFFF00);
            fb_fillrect(x + 3, iy + 3, 14, 3, 0xE0E000);
            fb_rect3d(x + 3, iy + 3, 14, 11, 0xFFFF80, 0x808000);
            fb_drawstr(x + 20, iy + 3, fs[s].name, 0xFFFF80, bg);
        }
        else
        {
            /* File icon */
            fb_fillrect(x + 4, iy + 2, 12, 14, 0xEEEEEE);
            fb_rect3d(x + 4, iy + 2, 12, 14, 0xFFFFFF, 0x808080);
            fb_drawstr(x + 20, iy + 3, fs[s].name, 0xCCCCCC, bg);
        }
        shown++;
        si++;
    }

    /* Scroll indicator */
    if (item_count > items_shown)
    {
        int sx = w->x + w->w - 8;
        int bar_h = ch - 30;
        int thumb_h = bar_h * items_shown / item_count;
        if (thumb_h < 8) thumb_h = 8;
        int thumb_y = y + bar_h * scroll_offset / item_count;
        fb_fillrect(sx, y, 5, bar_h, 0x333355);
        fb_fillrect(sx, thumb_y, 5, thumb_h, 0x8888AA);
        fb_rect3d(sx, thumb_y, 5, thumb_h, 0xAAAAFF, 0x555577);
    }

    fb_rect3d(x - 2, w->y + TITLE_H, w->w + 4, w->h - TITLE_H, 0xFFFFFF, 0x808080);
}

static void exp_click(wnd_t *w, int mx, int my)
{
    (void)w; (void)mx;
    int y0 = w->y + TITLE_H + 24;
    if (my < y0) return;

    int idx = (my - y0) / 20 + scroll_offset;
    if (idx < 0) return;

    int si = 0;
    for (int s = fs[current_idx].first_child; s >= 0; s = fs[s].next_sibling)
    {
        if (si == idx)
        {
            if (fs[s].is_dir)
            {
                current_idx = s;
                scroll_offset = 0;
            } else {
                notepad_open(fs[s].name, 0, 0);
            }
            return;
        }
        si++;
    }
}

static void exp_key(wnd_t *w, char c)
{
    (void)w;
    if (c == '\b') {
        if (current_idx > 0) {
            current_idx = fs[current_idx].parent;
            scroll_offset = 0;
        }
    }
}

static void exp_on_close(wnd_t *w)
{
    (void)w;
    exp_wnd = 0;
}

void explorer_open(void)
{
    if (exp_wnd)
    {
        if (exp_wnd->flags & WND_VISIBLE) { wm_raise(exp_wnd); return; }
        wm_restore(exp_wnd);
        return;
    }
    if (fs_count == 0) init_filesystem();
    current_idx = 0;
    scroll_offset = 0;
    exp_wnd = wm_create(200, 80, 340, 320, "My Computer");
    if (!exp_wnd) return;
    exp_wnd->render = exp_render;
    exp_wnd->key = exp_key;
    exp_wnd->click = exp_click;
    exp_wnd->data = 0;
    exp_wnd->on_close = exp_on_close;
}
