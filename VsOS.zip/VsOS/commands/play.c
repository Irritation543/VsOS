#include "sound.h"
#include "shell.h"
#include "terminal.h"
#include "../arch/i386/io.h"

extern term_t main_term;

static uint32_t pci_read(uint8_t bus, uint8_t dev, uint8_t func, uint8_t reg)
{
    outl(0xCF8, 0x80000000 | ((uint32_t)bus << 16) |
                ((uint32_t)(dev & 31) << 11) |
                ((uint32_t)(func & 7) << 8) | (reg & 0xFC));
    return inl(0xCFC);
}

void cmd_play(int argc, char **argv)
{
    (void)argc; (void)argv;

    term_printf(&main_term, "=== PCI scan ===\n");
    int found_ac97 = 0;
    int found_mm = 0;
    for (int dev = 0; dev < 32; dev++) {
        for (int func = 0; func < 8; func++) {
            uint32_t vid = pci_read(0, dev, func, 0);
            uint16_t vendor = vid & 0xFFFF;
            uint16_t device = (vid >> 16) & 0xFFFF;
            if (vendor == 0xFFFF && func == 0) break;
            if (vendor == 0xFFFF) continue;

            uint32_t cc  = pci_read(0, dev, func, 0x08);
            uint8_t cls  = (cc >> 24) & 0xFF;
            uint8_t sub  = (cc >> 16) & 0xFF;
            uint8_t prog = (cc >> 8) & 0xFF;

            uint32_t bar0 = pci_read(0, dev, func, 0x10);
            uint32_t bar1 = pci_read(0, dev, func, 0x14);

            term_printf(&main_term, "  %u.%u %x:%x class=%x:%x prog=%x BAR0=%x BAR1=%x\n",
                   dev, func, vendor, device, cls, sub, prog, bar0, bar1);

            if (cls == 0x04 && sub == 0x01) found_mm = 1;
            if (vendor == 0x8086 && device == 0x2415) found_ac97 = 1;
        }
    }

    term_printf(&main_term, "AC97 vid/ID: %s\n", found_ac97 ? "FOUND" : "NF");
    term_printf(&main_term, "AC97 class: %s\n", found_mm ? "FOUND" : "NF");

    term_printf(&main_term, "\nAC97 info: ");
    char buf[64];
    ac97_get_info(buf, 64);
    term_printf(&main_term, "%s\n", buf);

    if (!ac97_init()) {
        term_printf(&main_term, "AC97 init FAILED\n");
        return;
    }
    term_printf(&main_term, "AC97 init OK\n");

    extern uint16_t nambar, nabmbar;
    term_printf(&main_term, "NAMBAR=%x NABMBAR=%x\n", nambar, nabmbar);

    term_printf(&main_term, "\nMixer:\n");
    for (int r = 0; r < 0x80; r += 2) {
        uint16_t v = inw(nambar + r);
        if (v != 0xFFFF)
            term_printf(&main_term, " [%x]=%x\n", r, v);
    }

    term_printf(&main_term, "\nBus master:\n");
    term_printf(&main_term, " SR=%x\n", inw(nabmbar + 0x16));
    term_printf(&main_term, " CR=%x\n", inb(nabmbar + 0x1A));
    term_printf(&main_term, " CIV=%x\n", inb(nabmbar + 0x14));
    term_printf(&main_term, " PICB=%x\n", inw(nabmbar + 0x18));

    term_printf(&main_term, "\nDMA diag:\n");
    term_printf(&main_term, "bdl=%x buf=%x\n",
           ac97_get_bdl_addr(), ac97_get_buf_addr());
    term_printf(&main_term, "bdl_a=%d buf_a=%d\n",
           ac97_get_bdl_aligned(), ac97_get_buf_aligned());

    int diag = ac97_diag();
    if (diag < 0) {
        term_printf(&main_term, "diag err: %d\n", diag);
    } else {
        int typ = (diag >> 16) & 0xFF;
        if (typ == 0x10) {
            term_printf(&main_term, "REG mismatch: BDBAR_lo=%x LVI=%x\n", diag & 0xFF, (diag >> 8) & 0xFF);
        } else if (typ == 0x11) {
            term_printf(&main_term, "DMA OK sr=%x civ=%x cr=%x\n", diag & 0xFF, (diag >> 8) & 0xFF, (diag >> 12) & 0xF);
        } else if (typ == 0x12) {
            int sr_before = (diag >> 24) & 0xFF;
            int civ_start = (diag >> 20) & 0xF;
            term_printf(&main_term, "STUCK sr=%x civ=%x cr=%x sr_before=%x civ_start=%x\n",
                   diag & 0xFF, (diag >> 8) & 0xFF, (diag >> 12) & 0xF, sr_before, civ_start);
        }
    }

    term_printf(&main_term, "\nPlay 440Hz 500ms:\n");
    int ret = ac97_play_wav(0, 0);
    const char *errtxt = "OK";
    if (ret == -2) errtxt = "BDL_ALIGN";
    else if (ret == -3) errtxt = "BUF_ALIGN";
    else if (ret == -4) errtxt = "BCIS";
    else if (ret == -5) errtxt = "RUN_FAIL";
    else if (ret < 0) errtxt = "INIT";
    term_printf(&main_term, "ret=%d (%s)\n", ret, errtxt);

    term_printf(&main_term, "\nAfter:\n");
    term_printf(&main_term, " SR=%x\n", inw(nabmbar + 0x16));
    term_printf(&main_term, " CR=%x\n", inb(nabmbar + 0x1A));
    term_printf(&main_term, " CIV=%x\n", inb(nabmbar + 0x14));
    term_printf(&main_term, " PICB=%x\n", inw(nabmbar + 0x18));
}
