#include "scanner.h"
#include "shell.h"
#include "terminal.h"

extern term_t main_term;

void cmd_scan(int argc, char **argv)
{
    (void)argc; (void)argv;
    scan_open();
    term_printf(&main_term, "Scan window opened.\n");
}
