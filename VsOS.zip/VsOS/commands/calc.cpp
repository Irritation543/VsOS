extern "C" {
extern void video_write(const char *str);
extern void video_printf(const char *fmt, ...);
extern int atoi(const char *s);
}

class Calc {
public:
    static int eval(int a, char op, int b)
    {
        switch (op)
        {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/': return b ? a / b : 0;
            default:  return 0;
        }
    }
};

extern "C" void cmd_calc(int argc, char **argv)
{
    if (argc != 4)
    {
        video_write("Usage: calc <a> <op> <b>\n");
        video_write("Example: calc 2 + 3\n");
        return;
    }
    int a = atoi(argv[1]);
    char op = argv[2][0];
    int b = atoi(argv[3]);
    int r = Calc::eval(a, op, b);
    video_printf("%d %c %d = %d\n", a, op, b, r);
}
