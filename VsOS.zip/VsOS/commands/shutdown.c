#include "sound.h"
#include "../arch/i386/io.h"

void cmd_shutdown(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    ac97_play_shutdown();
    /* Small delay to let sound engine finish */
    for (volatile int i = 0; i < 1000000; i++) asm("pause");
    outw(0x2000, 0x604);
    outw(0x2000, 0xB004);
    halt();
}
