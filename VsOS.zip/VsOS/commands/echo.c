extern void video_write(const char *str);
extern void video_putchar(char c);

void cmd_echo(int argc, char **argv)
{
    for (int i = 1; i < argc; i++)
    {
        if (i > 1) video_putchar(' ');
        video_write(argv[i]);
    }
    video_write("\n");
}
