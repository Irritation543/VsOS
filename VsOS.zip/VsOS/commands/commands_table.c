extern void cmd_help(int argc, char **argv);
extern void cmd_whoami(int argc, char **argv);
extern void cmd_calc(int argc, char **argv);
extern void cmd_echo(int argc, char **argv);
extern void cmd_clear(int argc, char **argv);
extern void cmd_shutdown(int argc, char **argv);
extern void cmd_beep(int argc, char **argv);
extern void cmd_play(int argc, char **argv);
extern void cmd_scan(int argc, char **argv);

typedef void (*cmd_t)(int, char **);

typedef struct {
    const char *name;
    const char *desc;
    cmd_t handler;
} cmd_entry_t;

cmd_entry_t commands[] = {
    {"help",     "Show this help message",                  cmd_help},
    {"whoami",   "Print current user name",                 cmd_whoami},
    {"calc",     "Arithmetic: calc <a> <+|-|*|/> <b>",     cmd_calc},
    {"echo",     "Echo back the input text",                cmd_echo},
    {"clear",    "Clear the screen",                        cmd_clear},
    {"shutdown", "Shutdown the system",                     cmd_shutdown},
    {"beep",     "Beep PC speaker: beep [freq] [ms]",        cmd_beep},
    {"play",     "Play test tone via AC97 audio",            cmd_play},
    {"scan",     "Run system diagnostics",                   cmd_scan},
};

int commands_count = sizeof(commands) / sizeof(commands[0]);
