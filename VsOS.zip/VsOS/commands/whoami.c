extern void video_write(const char *str);

void cmd_whoami(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    video_write("user\n");
}
