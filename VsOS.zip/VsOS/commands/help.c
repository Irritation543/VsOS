extern void video_write(const char *str);
extern void video_printf(const char *fmt, ...);

typedef void (*cmd_t)(int, char **);

typedef struct {
    const char *name;
    const char *desc;
    cmd_t handler;
} cmd_entry_t;

extern cmd_entry_t commands[];
extern int commands_count;

void cmd_help(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    video_write("\nVsOS v0.1  --  Available commands:\n\n");
    for (int i = 0; i < commands_count; i++)
    {
        video_write("  ");
        video_write(commands[i].name);
        video_write("\n      ");
        video_write(commands[i].desc);
        video_write("\n");
    }
    video_write("\n");
}
