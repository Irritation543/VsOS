extern void video_clear(void);

void cmd_clear(int argc, char **argv)
{
    (void)argc;
    (void)argv;
    video_clear();
}
