#include "sound.h"
#include "string.h"

void cmd_beep(int argc, char **argv)
{
    int freq = 440;
    int dur = 500;

    if (argc > 1) {
        freq = atoi(argv[1]);
        if (freq <= 0) freq = 440;
    }
    if (argc > 2) {
        dur = atoi(argv[2]);
        if (dur <= 0) dur = 500;
    }

    beep(freq, dur);
}
