global _inb, _inw, _inl, _outb, _outw, _outl, _halt

section .text

_inb:
    mov dx, [esp + 4]
    xor eax, eax
    in al, dx
    ret

_inw:
    mov dx, [esp + 4]
    xor eax, eax
    in ax, dx
    ret

_inl:
    mov dx, [esp + 4]
    xor eax, eax
    in eax, dx
    ret

_outb:
    mov dx, [esp + 4]
    mov al, [esp + 8]
    out dx, al
    ret

_outw:
    mov dx, [esp + 4]
    mov ax, [esp + 8]
    out dx, ax
    ret

_outl:
    mov dx, [esp + 4]
    mov eax, [esp + 8]
    out dx, eax
    ret

_halt:
    cli
    hlt
    ret
