section .multiboot
align 4
    dd 0x1BADB002
    dd 0x03
    dd -(0x1BADB002 + 0x03)

section .text
global _start
extern _kernel_main

_start:
    mov esp, _stack_top
    push ebx
    push eax
    call _kernel_main
    cli
    hlt

section .bss
align 16
_stack_bottom:
    resb 16384
_stack_top:
